import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import Image from "next/image"

async function getAboutPageData(locale: Locale) {
  try {
    const pageData = await fetchAPI("/about-page", {
      populate: {
        sections: {
          populate: "*",
        },
        team: {
          populate: "*",
        },
        seo: {
          populate: "*",
        },
      },
      locale,
    })

    return (
      pageData?.data?.attributes || {
        title: "About Us",
        subtitle: "Learn more about Baglamukhi Pujan and our mission",
        sections: [],
        team: { members: [] },
        seo: {},
      }
    )
  } catch (error) {
    console.error("Error fetching about page data:", error)
    return {
      title: "About Us",
      subtitle: "Learn more about Baglamukhi Pujan and our mission",
      sections: [],
      team: { members: [] },
      seo: {},
    }
  }
}

export default async function AboutPage({ params }: { params: { locale: Locale } }) {
  const { locale } = params
  const dict = await getDictionary(locale)
  const page = await getAboutPageData(locale)

  // Default values if data is not available
  const title = page?.title || "About Us"
  const subtitle = page?.subtitle || "Learn more about Baglamukhi Pujan and our mission"

  // Default sections if none are provided
  const defaultSections = [
    {
      title: dict.about.ourStory,
      content: `<p>Baglamukhi Pujan was founded with a vision to connect devotees with temples and tirth kshetras across India. Our journey began with a simple idea - to make spiritual practices accessible to everyone, regardless of their location.</p>
      <p>Over the years, we have grown into a trusted platform for booking pujas, listening to aartis, and learning mantras. We have partnered with renowned temples and experienced pandits to ensure authentic rituals and spiritual experiences.</p>`,
      image: null,
    },
    {
      title: dict.about.mission,
      content: `<p>Our mission is to preserve and promote the rich spiritual heritage of India by making it accessible to devotees worldwide. We aim to create a bridge between devotees and temples, enabling them to participate in sacred rituals and receive divine blessings.</p>
      <p>We are committed to providing authentic spiritual experiences, maintaining the sanctity of rituals, and ensuring transparency in all our services.</p>`,
      image: null,
    },
    {
      title: dict.about.vision,
      content: `<p>We envision a world where geographical boundaries do not limit one's spiritual journey. We strive to create a global community of devotees connected through faith and devotion.</p>
      <p>Our vision extends beyond just providing services - we aim to educate, inspire, and empower individuals on their spiritual path, helping them connect with the divine and experience inner peace and fulfillment.</p>`,
      image: null,
    },
  ]

  const sections = page?.sections?.length > 0 ? page.sections : defaultSections

  // Default team members if none are provided
  const defaultTeamMembers = [
    {
      name: "Rajesh Sharma",
      position: "Founder & CEO",
      bio: "Rajesh has over 20 years of experience in spiritual practices and temple management. He founded Baglamukhi Pujan with a vision to connect devotees with temples across India.",
      image: null,
    },
    {
      name: "Priya Patel",
      position: "Chief Spiritual Officer",
      bio: "Priya is a scholar of Vedic scriptures and has deep knowledge of rituals and mantras. She ensures the authenticity and sanctity of all pujas performed through our platform.",
      image: null,
    },
    {
      name: "Amit Verma",
      position: "Head of Temple Relations",
      bio: "Amit works closely with temples and pandits across India to build partnerships and ensure seamless puja services for our devotees.",
      image: null,
    },
  ]

  const teamMembers = page?.team?.members?.length > 0 ? page.team.members : defaultTeamMembers

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">{title}</h1>
        <p className="text-gray-600">{subtitle}</p>
      </div>

      {sections.map((section: any, i: number) => (
        <section key={i} className={`py-12 ${i % 2 === 1 ? "bg-orange-50" : "bg-white"}`}>
          <div className="container mx-auto px-4">
            <div className={`grid md:grid-cols-2 gap-8 items-center ${i % 2 === 1 ? "md:flex-row-reverse" : ""}`}>
              <div className="space-y-4">
                <h2 className="text-2xl md:text-3xl font-bold mb-4">{section.title}</h2>
                <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: section.content || "" }} />
              </div>
              <div className="relative h-[300px] rounded-lg overflow-hidden">
                <Image src="/placeholder.svg?height=300&width=500" alt={section.title} fill className="object-cover" />
              </div>
            </div>
          </div>
        </section>
      ))}

      <section className="py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">{dict.about.team}</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {teamMembers.map((member: any, i: number) => (
              <div key={i} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative h-64">
                  <Image src="/placeholder.svg?height=250&width=250" alt={member.name} fill className="object-cover" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                  <p className="text-orange-600 text-sm mb-4">{member.position}</p>
                  <p className="text-gray-600">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}

