import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"
import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Play, Download } from "lucide-react"

async function getMantraData(slug: string, locale: Locale) {
  try {
    const data = await fetchAPI(`/mantras`, {
      filters: {
        slug: {
          $eq: slug,
        },
      },
      populate: "*",
      locale,
    })

    if (!data.data || data.data.length === 0) {
      return null
    }

    return data.data[0]
  } catch (error) {
    console.error(`Error fetching mantra data for slug ${slug}:`, error)
    return null
  }
}

// Sample mantra data for when API returns nothing
const getSampleMantra = (slug: string) => ({
  id: "sample-1",
  attributes: {
    title: "Baglamukhi Mantra",
    deity: "Maa Baglamukhi",
    count: "108 times",
    description:
      "The Baglamukhi Mantra is a powerful mantra dedicated to Goddess Baglamukhi, the eighth Mahavidya. Chanting this mantra helps in overcoming enemies, winning court cases, and removing obstacles.",
    mantra: "ॐ ह्लीं बगलामुखी सर्वदुष्टानां वाचं मुखं पदं स्तम्भय जिह्वां कीलय बुद्धिं विनाशय ह्लीं ॐ स्वाहा॥",
    meaning:
      "<p>This mantra invokes the power of Goddess Baglamukhi to paralyze the speech, mouth, feet, and tongue of enemies, and to destroy their intellect.</p><p>The mantra begins with 'Om', the primordial sound, followed by 'Hleem', the seed syllable of Goddess Baglamukhi. The mantra then addresses the goddess directly, asking her to paralyze the speech, mouth, and feet of all evil-doers, to nail their tongues, and to destroy their intellect.</p>",
    benefits: [
      { text: "Protection from enemies and negative forces" },
      { text: "Success in legal matters and disputes" },
      { text: "Removal of obstacles and hurdles" },
      { text: "Enhanced mental strength and clarity" },
      { text: "Protection from black magic and evil eye" },
    ],
    howToChant:
      "<p>To chant the Baglamukhi Mantra effectively, follow these steps:</p><ol><li>Choose a clean and quiet place for chanting.</li><li>Sit in a comfortable position, preferably facing East or North.</li><li>Light a yellow candle and incense stick.</li><li>Begin by taking deep breaths to calm your mind.</li><li>Chant the mantra 108 times using a yellow mala (prayer beads).</li><li>The best time to chant is during sunrise or sunset.</li><li>Chant with full concentration and devotion.</li></ol>",
    audioUrl: "#",
    slug: slug,
  },
})

export default async function MantraDetailPage({
  params,
}: {
  params: { locale: Locale; slug: string }
}) {
  const { locale, slug } = params
  const dict = await getDictionary(locale)
  let mantra = await getMantraData(slug, locale)

  // Use sample data if API returns nothing
  if (!mantra) {
    mantra = getSampleMantra(slug)
  }

  if (!mantra) {
    notFound()
  }

  const {
    title = "Mantra",
    deity = "Deity",
    count = "108 times",
    description = "No description available",
    mantra: mantraText = "",
    meaning = "",
    benefits = [],
    howToChant = "",
    audioUrl = "#",
  } = mantra.attributes || {}

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="flex items-center gap-2 text-sm text-gray-600 mb-6">
        <Link href={`/${locale}`} className="hover:text-orange-600">
          {dict.common.home}
        </Link>
        <span>/</span>
        <Link href={`/${locale}/mantras`} className="hover:text-orange-600">
          {dict.common.mantras}
        </Link>
        <span>/</span>
        <span className="text-gray-900 font-medium">{title}</span>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">{title}</h1>
          <p className="text-gray-600 mb-6">
            {deity} • Chant {count}
          </p>

          <p className="text-gray-700 mb-8">{description}</p>

          <div className="bg-orange-50 p-6 rounded-lg mb-8">
            <h3 className="font-semibold text-lg mb-4">Mantra</h3>
            <p className="text-xl text-center font-medium mb-4">{mantraText}</p>
            <div className="flex justify-center gap-4">
              <Button className="bg-orange-600 hover:bg-orange-700">
                <Play className="h-4 w-4 mr-2" />
                {dict.mantra.chant}
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                {dict.aarti.download}
              </Button>
            </div>
          </div>

          <Tabs defaultValue="meaning" className="w-full">
            <TabsList className="bg-orange-50 p-1 rounded-lg">
              <TabsTrigger value="meaning" className="data-[state=active]:bg-orange-600 data-[state=active]:text-white">
                {dict.mantra.meaning}
              </TabsTrigger>
              <TabsTrigger
                value="benefits"
                className="data-[state=active]:bg-orange-600 data-[state=active]:text-white"
              >
                {dict.mantra.benefits}
              </TabsTrigger>
              <TabsTrigger
                value="howToChant"
                className="data-[state=active]:bg-orange-600 data-[state=active]:text-white"
              >
                {dict.mantra.howToChant}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="meaning" className="mt-6">
              <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: meaning || "" }} />
            </TabsContent>

            <TabsContent value="benefits" className="mt-6">
              <ul className="space-y-2">
                {benefits && benefits.length > 0 ? (
                  benefits.map((benefit: any, i: number) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="bg-orange-100 text-orange-800 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span>{benefit.text}</span>
                    </li>
                  ))
                ) : (
                  <li>No benefits specified</li>
                )}
              </ul>
            </TabsContent>

            <TabsContent value="howToChant" className="mt-6">
              <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: howToChant || "" }} />
            </TabsContent>
          </Tabs>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-orange-50 rounded-lg p-6 sticky top-24">
            <div className="relative h-48 mb-6 rounded-lg overflow-hidden">
              <Image src="/placeholder.svg?height=200&width=300" alt={title} fill className="object-cover" />
            </div>

            <h3 className="text-xl font-bold mb-4">Related Mantras</h3>

            <div className="space-y-4">
              <div className="flex gap-3 items-center">
                <div className="bg-orange-100 rounded-md h-12 w-12 flex-shrink-0 flex items-center justify-center">
                  <span className="text-orange-600 font-semibold">ॐ</span>
                </div>
                <div>
                  <h4 className="font-medium">Gayatri Mantra</h4>
                  <p className="text-xs text-gray-500">Goddess Gayatri</p>
                </div>
              </div>

              <div className="flex gap-3 items-center">
                <div className="bg-orange-100 rounded-md h-12 w-12 flex-shrink-0 flex items-center justify-center">
                  <span className="text-orange-600 font-semibold">ॐ</span>
                </div>
                <div>
                  <h4 className="font-medium">Mahamrityunjaya Mantra</h4>
                  <p className="text-xs text-gray-500">Lord Shiva</p>
                </div>
              </div>

              <div className="flex gap-3 items-center">
                <div className="bg-orange-100 rounded-md h-12 w-12 flex-shrink-0 flex items-center justify-center">
                  <span className="text-orange-600 font-semibold">ॐ</span>
                </div>
                <div>
                  <h4 className="font-medium">Ganesh Mantra</h4>
                  <p className="text-xs text-gray-500">Lord Ganesha</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

