import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

async function getMantrasPageData(locale: Locale) {
  try {
    const pageData = await fetchAPI("/mantra-page", {
      populate: {
        seo: {
          populate: "*",
        },
      },
      locale,
    })

    const mantras = await fetchAPI("/mantras", {
      populate: "*",
      locale,
    })

    return {
      page: pageData?.data?.attributes || {
        title: "Mantras",
        subtitle: "Learn and chant powerful mantras for spiritual growth and divine blessings",
        seo: {},
      },
      mantras: mantras?.data || [],
    }
  } catch (error) {
    console.error("Error fetching mantras page data:", error)
    return {
      page: {
        title: "Mantras",
        subtitle: "Learn and chant powerful mantras for spiritual growth and divine blessings",
        seo: {},
      },
      mantras: [],
    }
  }
}

export default async function MantrasPage({ params }: { params: { locale: Locale } }) {
  const { locale } = params
  const dict = await getDictionary(locale)
  const { page, mantras } = await getMantrasPageData(locale)

  // Default values if data is not available
  const title = page?.title || "Mantras"
  const subtitle = page?.subtitle || "Learn and chant powerful mantras for spiritual growth and divine blessings"

  // Sample mantras for when API returns empty
  const sampleMantras = [
    {
      id: 1,
      attributes: {
        title: "Baglamukhi Mantra",
        deity: "Maa Baglamukhi",
        count: "108 times",
        slug: "baglamukhi-mantra",
        image: null,
      },
    },
    {
      id: 2,
      attributes: {
        title: "Gayatri Mantra",
        deity: "Goddess Gayatri",
        count: "108 times",
        slug: "gayatri-mantra",
        image: null,
      },
    },
    {
      id: 3,
      attributes: {
        title: "Mahamrityunjaya Mantra",
        deity: "Lord Shiva",
        count: "108 times",
        slug: "mahamrityunjaya-mantra",
        image: null,
      },
    },
    {
      id: 4,
      attributes: {
        title: "Lakshmi Mantra",
        deity: "Goddess Lakshmi",
        count: "108 times",
        slug: "lakshmi-mantra",
        image: null,
      },
    },
    {
      id: 5,
      attributes: {
        title: "Ganesh Mantra",
        deity: "Lord Ganesha",
        count: "108 times",
        slug: "ganesh-mantra",
        image: null,
      },
    },
    {
      id: 6,
      attributes: {
        title: "Hanuman Mantra",
        deity: "Lord Hanuman",
        count: "108 times",
        slug: "hanuman-mantra",
        image: null,
      },
    },
  ]

  // Use sample mantras if API returns empty
  const displayMantras = mantras.length > 0 ? mantras : sampleMantras

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">{title}</h1>
        <p className="text-gray-600">{subtitle}</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayMantras.map((mantra: any) => (
          <Link key={mantra.id} href={`/${locale}/mantras/${mantra.attributes.slug}`}>
            <Card className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative h-48 bg-orange-100">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt={mantra.attributes.title}
                  fill
                  className="object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <h3 className="font-bold text-lg text-white">{mantra.attributes.title}</h3>
                </div>
              </div>
              <CardContent className="p-4">
                <p className="text-gray-600 text-sm mb-2">{mantra.attributes.deity}</p>
                <p className="text-xs text-gray-500">Chant {mantra.attributes.count}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}

