import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import Image from "next/image"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import { Card, CardContent } from "@/components/ui/card"

async function getBlogPageData(locale: Locale) {
  try {
    const pageData = await fetchAPI("/blog-page", {
      populate: {
        seo: {
          populate: "*",
        },
      },
      locale,
    })

    const blogs = await fetchAPI("/blogs", {
      populate: "*",
      sort: "publishedAt:desc",
      locale,
    })

    return {
      page: pageData?.data?.attributes || {
        title: "Blog",
        subtitle: "Explore spiritual wisdom, temple stories, and more",
        seo: {},
      },
      blogs: blogs?.data || [],
    }
  } catch (error) {
    console.error("Error fetching blog page data:", error)
    return {
      page: {
        title: "Blog",
        subtitle: "Explore spiritual wisdom, temple stories, and more",
        seo: {},
      },
      blogs: [],
    }
  }
}

export default async function BlogPage({ params }: { params: { locale: Locale } }) {
  const { locale } = params
  const dict = await getDictionary(locale)
  const { page, blogs } = await getBlogPageData(locale)

  // Default values if data is not available
  const title = page?.title || "Blog"
  const subtitle = page?.subtitle || "Explore spiritual wisdom, temple stories, and more"

  // Sample blogs for when API returns empty
  const sampleBlogs = [
    {
      id: 1,
      attributes: {
        title: "The Power of Baglamukhi Puja",
        excerpt:
          "Discover the transformative power of Baglamukhi Puja and how it can help overcome obstacles in your life.",
        publishedAt: new Date().toISOString(),
        slug: "power-of-baglamukhi-puja",
        author: { data: { attributes: { name: "Rajesh Sharma" } } },
        image: null,
      },
    },
    {
      id: 2,
      attributes: {
        title: "Understanding the Significance of Mantras",
        excerpt:
          "Mantras are more than just words - they are powerful vibrations that can transform your consciousness. Learn about their significance.",
        publishedAt: new Date().toISOString(),
        slug: "significance-of-mantras",
        author: { data: { attributes: { name: "Priya Patel" } } },
        image: null,
      },
    },
    {
      id: 3,
      attributes: {
        title: "The History of Baglamukhi Temple",
        excerpt:
          "Explore the rich history and cultural significance of the ancient Baglamukhi Temple in Kangra, Himachal Pradesh.",
        publishedAt: new Date().toISOString(),
        slug: "history-of-baglamukhi-temple",
        author: { data: { attributes: { name: "Amit Verma" } } },
        image: null,
      },
    },
    {
      id: 4,
      attributes: {
        title: "Spiritual Practices for Daily Life",
        excerpt:
          "Incorporate these simple spiritual practices into your daily routine to enhance your spiritual growth and well-being.",
        publishedAt: new Date().toISOString(),
        slug: "spiritual-practices-daily-life",
        author: { data: { attributes: { name: "Sunita Gupta" } } },
        image: null,
      },
    },
  ]

  // Use sample blogs if API returns empty
  const displayBlogs = blogs.length > 0 ? blogs : sampleBlogs

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">{title}</h1>
        <p className="text-gray-600">{subtitle}</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayBlogs.map((blog: any) => (
          <Link key={blog.id} href={`/${locale}/blog/${blog.attributes.slug}`}>
            <Card className="overflow-hidden hover:shadow-lg transition-shadow h-full flex flex-col">
              <div className="relative h-48 bg-orange-100">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt={blog.attributes.title}
                  fill
                  className="object-cover"
                />
              </div>
              <CardContent className="p-6 flex-grow flex flex-col">
                <div className="mb-2 text-sm text-gray-500">
                  {formatDate(blog.attributes.publishedAt, locale)} •
                  {blog.attributes.author?.data?.attributes?.name || "Anonymous"}
                </div>
                <h3 className="font-bold text-lg mb-2">{blog.attributes.title}</h3>
                <p className="text-gray-600 mb-4 flex-grow">{blog.attributes.excerpt}</p>
                <div className="text-orange-600 font-medium">Read More →</div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}

