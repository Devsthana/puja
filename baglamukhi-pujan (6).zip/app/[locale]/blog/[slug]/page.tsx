import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"
import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import { formatDate } from "@/lib/utils"

async function getBlogData(slug: string, locale: Locale) {
  try {
    const data = await fetchAPI(`/blogs`, {
      filters: {
        slug: {
          $eq: slug,
        },
      },
      populate: "*",
      locale,
    })

    if (!data.data || data.data.length === 0) {
      return null
    }

    return data.data[0]
  } catch (error) {
    console.error(`Error fetching blog data for slug ${slug}:`, error)
    return null
  }
}

// Sample blog data for when API returns nothing
const getSampleBlog = (slug: string) => ({
  id: "sample-1",
  attributes: {
    title: "The Power of Baglamukhi Puja",
    excerpt:
      "Discover the transformative power of Baglamukhi Puja and how it can help overcome obstacles in your life.",
    content: `<p>Baglamukhi Puja is one of the most powerful rituals in Hindu tradition, dedicated to Goddess Baglamukhi, the eighth Mahavidya. Known as the "Paralyzer of enemies," she is depicted with a yellow face and wearing yellow clothes, holding a club in her right hand with which she beats a demon.</p>
    
    <h2>The Significance of Baglamukhi Puja</h2>
    
    <p>Baglamukhi Puja is performed to overcome enemies, win court cases, and remove obstacles. The goddess Baglamukhi is known for her power to paralyze enemies and negative forces. Her worship is particularly beneficial for those facing legal issues, conflicts, or any form of opposition.</p>
    
    <p>The yellow color associated with Goddess Baglamukhi symbolizes transformation and victory. The puja involves the use of yellow items such as yellow flowers, yellow clothes, turmeric, and yellow sweets.</p>
    
    <h2>Benefits of Baglamukhi Puja</h2>
    
    <p>Performing Baglamukhi Puja can bring numerous benefits to the devotee:</p>
    
    <ul>
      <li>Protection from enemies and negative forces</li>
      <li>Success in legal matters and disputes</li>
      <li>Removal of obstacles and hurdles</li>
      <li>Enhanced mental strength and clarity</li>
      <li>Protection from black magic and evil eye</li>
    </ul>
    
    <h2>How to Perform Baglamukhi Puja</h2>
    
    <p>Baglamukhi Puja should ideally be performed on a Thursday, which is considered auspicious for the goddess. The puja involves several steps, including:</p>
    
    <ol>
      <li>Setting up the altar with a yellow cloth</li>
      <li>Placing the idol or picture of Goddess Baglamukhi</li>
      <li>Offering yellow flowers, turmeric, and yellow sweets</li>
      <li>Lighting a yellow candle and incense</li>
      <li>Reciting the Baglamukhi Mantra 108 times</li>
      <li>Performing aarti</li>
    </ol>
    
    <p>It is recommended to perform the puja with the guidance of an experienced priest to ensure all rituals are performed correctly.</p>
    
    <h2>Conclusion</h2>
    
    <p>Baglamukhi Puja is a powerful ritual that can bring positive changes in one's life. By invoking the blessings of Goddess Baglamukhi, devotees can overcome obstacles, defeat enemies, and achieve success in their endeavors.</p>`,
    publishedAt: new Date().toISOString(),
    author: { data: { attributes: { name: "Rajesh Sharma", bio: "Founder & CEO of Baglamukhi Pujan" } } },
    image: null,
    relatedBlogs: { data: [] },
    slug: slug,
  },
})

async function getRelatedBlogs(locale: Locale, currentBlogId: string) {
  try {
    const data = await fetchAPI(`/blogs`, {
      filters: {
        id: {
          $ne: currentBlogId,
        },
      },
      populate: "*",
      pagination: {
        limit: 3,
      },
      locale,
    })

    return data.data || []
  } catch (error) {
    console.error("Error fetching related blogs:", error)
    return []
  }
}

export default async function BlogDetailPage({
  params,
}: {
  params: { locale: Locale; slug: string }
}) {
  const { locale, slug } = params
  const dict = await getDictionary(locale)
  let blog = await getBlogData(slug, locale)

  // Use sample data if API returns nothing
  if (!blog) {
    blog = getSampleBlog(slug)
  }

  if (!blog) {
    notFound()
  }

  // Get related blogs
  let relatedBlogs = blog.attributes.relatedBlogs?.data || []

  // If no related blogs are specified, fetch some
  if (relatedBlogs.length === 0) {
    relatedBlogs = await getRelatedBlogs(locale, blog.id)
  }

  // Sample related blogs if none are available
  if (relatedBlogs.length === 0) {
    relatedBlogs = [
      {
        id: "related-1",
        attributes: {
          title: "Understanding the Significance of Mantras",
          excerpt:
            "Mantras are more than just words - they are powerful vibrations that can transform your consciousness.",
          publishedAt: new Date().toISOString(),
          slug: "significance-of-mantras",
          image: null,
        },
      },
      {
        id: "related-2",
        attributes: {
          title: "The History of Baglamukhi Temple",
          excerpt: "Explore the rich history and cultural significance of the ancient Baglamukhi Temple in Kangra.",
          publishedAt: new Date().toISOString(),
          slug: "history-of-baglamukhi-temple",
          image: null,
        },
      },
      {
        id: "related-3",
        attributes: {
          title: "Spiritual Practices for Daily Life",
          excerpt:
            "Incorporate these simple spiritual practices into your daily routine to enhance your spiritual growth.",
          publishedAt: new Date().toISOString(),
          slug: "spiritual-practices-daily-life",
          image: null,
        },
      },
    ]
  }

  const {
    title = "Blog Post",
    excerpt = "",
    content = "",
    publishedAt = new Date().toISOString(),
    author = { data: { attributes: { name: "Anonymous", bio: "" } } },
  } = blog.attributes || {}

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="flex items-center gap-2 text-sm text-gray-600 mb-6">
        <Link href={`/${locale}`} className="hover:text-orange-600">
          {dict.common.home}
        </Link>
        <span>/</span>
        <Link href={`/${locale}/blog`} className="hover:text-orange-600">
          {dict.common.blog}
        </Link>
        <span>/</span>
        <span className="text-gray-900 font-medium">{title}</span>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <h1 className="text-2xl md:text-3xl font-bold mb-4">{title}</h1>

          <div className="flex items-center gap-4 mb-6">
            <div className="bg-orange-100 rounded-full h-10 w-10 flex items-center justify-center">
              <span className="text-orange-600 font-semibold">{author.data.attributes.name.charAt(0)}</span>
            </div>
            <div>
              <p className="font-medium">{author.data.attributes.name}</p>
              <p className="text-sm text-gray-500">{formatDate(publishedAt, locale)}</p>
            </div>
          </div>

          <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden mb-8">
            <Image src="/placeholder.svg?height=400&width=800" alt={title} fill className="object-cover" />
          </div>

          <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: content || "" }} />
        </div>

        <div className="lg:col-span-1">
          <div className="bg-orange-50 rounded-lg p-6 sticky top-24">
            <h3 className="text-xl font-bold mb-6">Related Articles</h3>

            <div className="space-y-6">
              {relatedBlogs.map((relatedBlog: any) => (
                <Link key={relatedBlog.id} href={`/${locale}/blog/${relatedBlog.attributes.slug}`}>
                  <div className="flex gap-4">
                    <div className="relative h-16 w-16 rounded-md overflow-hidden flex-shrink-0">
                      <Image
                        src="/placeholder.svg?height=64&width=64"
                        alt={relatedBlog.attributes.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-medium text-sm line-clamp-2">{relatedBlog.attributes.title}</h4>
                      <p className="text-xs text-gray-500 mt-1">
                        {formatDate(relatedBlog.attributes.publishedAt, locale)}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            <div className="mt-8 pt-6 border-t border-orange-200">
              <h3 className="font-bold mb-4">About the Author</h3>
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-orange-100 rounded-full h-12 w-12 flex items-center justify-center">
                  <span className="text-orange-600 font-semibold">{author.data.attributes.name.charAt(0)}</span>
                </div>
                <div>
                  <p className="font-medium">{author.data.attributes.name}</p>
                </div>
              </div>
              <p className="text-sm text-gray-600">
                {author.data.attributes.bio || "A passionate writer and spiritual enthusiast."}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

