import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { ContactForm } from "@/components/contact-form"
import { MapPin, Phone, Mail } from "lucide-react"

export default async function ContactPage({ params }: { params: { locale: Locale } }) {
  const { locale } = params
  const dict = await getDictionary(locale)

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">{dict.contact.getInTouch}</h1>
        <p className="text-gray-600">Get in touch with us for any queries or feedback</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
        <div>
          <div className="bg-orange-50 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-bold mb-6">{dict.contact.getInTouch}</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-orange-600 mt-1" />
                <div>
                  <h3 className="font-medium">{dict.contact.address}</h3>
                  <p className="text-gray-600">123 Temple Street, New Delhi, India</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-orange-600 mt-1" />
                <div>
                  <h3 className="font-medium">{dict.contact.phone}</h3>
                  <p className="text-gray-600">+91 98765 43210</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-orange-600 mt-1" />
                <div>
                  <h3 className="font-medium">{dict.contact.email}</h3>
                  <p className="text-gray-600">info@baglamukhipujan.com</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-200 rounded-lg h-[300px] flex items-center justify-center">
            <p className="text-gray-500">Map will be displayed here</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold mb-6">Send us a Message</h2>
          <ContactForm locale={locale} sendButtonText={dict.contact.sendMessage} />
        </div>
      </div>
    </div>
  )
}

