import Link from "next/link"
import { notFound } from "next/navigation"
import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Info } from "lucide-react"

async function getOfferingData(slug: string, locale: Locale) {
  try {
    const data = await fetchAPI(`/offerings`, {
      filters: {
        slug: {
          $eq: slug,
        },
      },
      populate: "*",
      locale,
    })

    if (!data.data || data.data.length === 0) {
      return null
    }

    return data.data[0]
  } catch (error) {
    console.error(`Error fetching offering data for slug ${slug}:`, error)
    return null
  }
}

// Sample offering data for when API returns nothing
const getSampleOffering = (slug: string) => ({
  id: "sample-1",
  attributes: {
    title: "Sample Offering",
    temple: "Sample Temple",
    price: "₹1,100",
    description: "This is a sample offering description when the API doesn't return data.",
    details: "<p>Detailed information about this offering would appear here.</p>",
    items: [{ text: "Sacred thread (Kalava)" }, { text: "Blessed prasad" }, { text: "Rudraksha" }, { text: "Yantra" }],
    benefits: [
      { text: "Brings peace and prosperity" },
      { text: "Removes obstacles" },
      { text: "Enhances spiritual growth" },
    ],
    options: [
      { name: "Basic Package", price: "₹1,100" },
      { name: "Standard Package", price: "₹2,100" },
      { name: "Premium Package", price: "₹3,100" },
    ],
    templeDescription: "<p>Information about the temple would appear here.</p>",
    slug: slug,
  },
})

export default async function OfferingDetailPage({
  params,
}: {
  params: { locale: Locale; slug: string }
}) {
  const { locale, slug } = params
  const dict = await getDictionary(locale)
  let offering = await getOfferingData(slug, locale)

  // Use sample data if API returns nothing
  if (!offering) {
    offering = getSampleOffering(slug)
  }

  if (!offering) {
    notFound()
  }

  const {
    title = "Offering Details",
    temple = "Temple Name",
    price = "₹1,100",
    description = "No description available",
    details = "",
    items = [],
    benefits = [],
    options = [],
    templeDescription = "",
  } = offering.attributes || {}

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="flex items-center gap-2 text-sm text-gray-600 mb-6">
        <Link href={`/${locale}`} className="hover:text-orange-600">
          {dict.common.home || "Home"}
        </Link>
        <span>/</span>
        <Link href={`/${locale}/offerings`} className="hover:text-orange-600">
          {dict.common.offerings || "Offerings"}
        </Link>
        <span>/</span>
        <span className="text-gray-900 font-medium">{title}</span>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden mb-8">
            <Image src="/placeholder.svg?height=400&width=800" alt={title} fill className="object-cover" />
          </div>

          <h1 className="text-2xl md:text-3xl font-bold mb-4">{title}</h1>

          <div className="flex items-center gap-2 text-gray-700 mb-6">
            <MapPin className="h-5 w-5 text-orange-600" />
            <span>{temple}</span>
          </div>

          <p className="text-gray-700 mb-8">{description}</p>

          <Tabs defaultValue="details" className="w-full">
            <TabsList className="bg-orange-50 p-1 rounded-lg">
              <TabsTrigger value="details" className="data-[state=active]:bg-orange-600 data-[state=active]:text-white">
                {dict.offering.details || "Details"}
              </TabsTrigger>
              <TabsTrigger value="items" className="data-[state=active]:bg-orange-600 data-[state=active]:text-white">
                {dict.offering.items || "Items Included"}
              </TabsTrigger>
              <TabsTrigger
                value="benefits"
                className="data-[state=active]:bg-orange-600 data-[state=active]:text-white"
              >
                {dict.offering.benefits || "Spiritual Benefits"}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="mt-6">
              <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: details || "" }} />
            </TabsContent>

            <TabsContent value="items" className="mt-6">
              <ul className="space-y-2">
                {items && items.length > 0 ? (
                  items.map((item: any, i: number) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="bg-orange-100 text-orange-800 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span>{item.text}</span>
                    </li>
                  ))
                ) : (
                  <li>No items specified</li>
                )}
              </ul>
            </TabsContent>

            <TabsContent value="benefits" className="mt-6">
              <ul className="space-y-2">
                {benefits && benefits.length > 0 ? (
                  benefits.map((benefit: any, i: number) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="bg-orange-100 text-orange-800 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span>{benefit.text}</span>
                    </li>
                  ))
                ) : (
                  <li>No benefits specified</li>
                )}
              </ul>
            </TabsContent>
          </Tabs>

          {templeDescription && (
            <div className="mt-12">
              <h2 className="text-xl font-bold mb-4">{dict.offering.aboutTemple || "About the Temple"}</h2>
              <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: templeDescription }} />
            </div>
          )}
        </div>

        <div className="lg:col-span-1">
          <div className="bg-orange-50 rounded-lg p-6 sticky top-24">
            <h2 className="text-xl font-bold mb-6">{dict.offering.bookYourOffering || "Book Your Offering"}</h2>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Select Package</label>
                <select className="w-full p-2 border rounded-md">
                  {options.map((option: any, i: number) => (
                    <option key={i} value={option.name}>
                      {option.name} - {option.price}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Quantity</label>
                <div className="flex">
                  <button className="px-3 py-1 border rounded-l-md">-</button>
                  <input type="number" min="1" value="1" className="w-16 text-center border-t border-b" readOnly />
                  <button className="px-3 py-1 border rounded-r-md">+</button>
                </div>
              </div>

              <Button className="w-full bg-orange-600 hover:bg-orange-700">{dict.common.bookNow || "Book Now"}</Button>
            </div>

            <div className="flex items-start gap-2 mt-6 text-sm">
              <Info className="h-5 w-5 text-orange-600 flex-shrink-0 mt-0.5" />
              <p className="text-gray-600">
                {dict.offering.priceNote || "Price includes all items and shipping within India."}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

