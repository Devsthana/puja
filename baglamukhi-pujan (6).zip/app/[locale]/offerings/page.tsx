import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"

async function getOfferingsPageData(locale: Locale) {
  try {
    const pageData = await fetchAPI("/offerings-page", {
      populate: {
        seo: {
          populate: "*",
        },
      },
      locale,
    })

    const offerings = await fetchAPI("/offerings", {
      populate: "*",
      locale,
    })

    return {
      page: pageData?.data?.attributes || {
        title: "Offerings",
        subtitle: "Bring home blessed items and prasad from sacred temples across India",
        featuredTitle: "Featured Offerings",
        allOfferingsTitle: "All Offerings",
        seo: {},
      },
      offerings: offerings?.data || [],
    }
  } catch (error) {
    console.error("Error fetching offerings page data:", error)
    return {
      page: {
        title: "Offerings",
        subtitle: "Bring home blessed items and prasad from sacred temples across India",
        featuredTitle: "Featured Offerings",
        allOfferingsTitle: "All Offerings",
        seo: {},
      },
      offerings: [],
    }
  }
}

export default async function OfferingsPage({ params }: { params: { locale: Locale } }) {
  const { locale } = params
  const dict = await getDictionary(locale)
  const { page, offerings } = await getOfferingsPageData(locale)

  // Default values if data is not available
  const title = page?.title || "Offerings"
  const subtitle = page?.subtitle || "Bring home blessed items and prasad from sacred temples across India"
  const allOfferingsTitle = page?.allOfferingsTitle || "All Offerings"

  // Sample offerings for display when API returns empty
  const sampleOfferings = [
    {
      id: 1,
      attributes: {
        title: "Prasad Package",
        temple: "Baglamukhi Temple",
        price: "₹501",
        shortDescription: "Blessed prasad from the sacred Baglamukhi Temple",
        slug: "prasad-package",
      },
    },
    {
      id: 2,
      attributes: {
        title: "Yantra and Rudraksha",
        temple: "Kashi Vishwanath",
        price: "₹1,100",
        shortDescription: "Sacred yantra and rudraksha blessed at Kashi Vishwanath",
        slug: "yantra-rudraksha",
      },
    },
    {
      id: 3,
      attributes: {
        title: "Puja Samagri Kit",
        temple: "Mahakaleshwar",
        price: "₹751",
        shortDescription: "Complete kit for performing puja at home",
        slug: "puja-samagri",
      },
    },
    {
      id: 4,
      attributes: {
        title: "Sacred Ash (Vibhuti)",
        temple: "Rameshwaram Temple",
        price: "₹301",
        shortDescription: "Sacred ash from the holy fire at Rameshwaram",
        slug: "sacred-ash",
      },
    },
  ]

  // Use sample offerings if API returns empty
  const displayOfferings = offerings.length > 0 ? offerings : sampleOfferings

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">{title}</h1>
        <p className="text-gray-600">{subtitle}</p>
      </div>

      <section>
        <h2 className="text-2xl font-bold mb-8">{allOfferingsTitle}</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {displayOfferings.map((offering: any) => (
            <Card key={offering.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative h-48">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt={offering.attributes.title}
                  fill
                  className="object-cover"
                />
              </div>
              <CardContent className="p-4">
                <h3 className="font-bold text-lg mb-2 line-clamp-1">{offering.attributes.title}</h3>
                <div className="flex items-center text-sm text-gray-600 mb-3">
                  <span className="line-clamp-1">{offering.attributes.temple}</span>
                </div>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">{offering.attributes.shortDescription}</p>
              </CardContent>
              <CardFooter className="p-4 pt-0 flex items-center justify-between">
                <div className="font-bold text-orange-600">{offering.attributes.price}</div>
                <Link
                  href={`/${locale}/offerings/${offering.attributes.slug}`}
                  className="text-orange-600 hover:text-orange-700 text-sm font-medium transition-colors"
                >
                  {dict.common.viewDetails || "View Details"} →
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}

