import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { UserDashboardClient } from "@/components/user-dashboard-client"

export default async function DashboardPage({ params }: { params: { locale: Locale } }) {
  const { locale } = params
  const dict = await getDictionary(locale)

  // Sample bookings data
  const bookings = [
    {
      id: "BKG001",
      title: "Baglamukhi Puja",
      temple: "Baglamukhi Temple, Kangra",
      date: "2023-12-15",
      time: "10:00 AM",
      status: "Confirmed",
      price: "₹1,100",
    },
    {
      id: "BKG002",
      title: "Maha Mrityunjaya Puja",
      temple: "Kashi Vishwanath Temple",
      date: "2023-12-20",
      time: "11:00 AM",
      status: "Pending",
      price: "₹2,100",
    },
  ]

  return (
    <UserDashboardClient
      locale={locale}
      bookings={bookings}
      translations={{
        dashboard: dict.user.dashboard,
        myBookings: dict.user.myBookings,
        profile: dict.user.profile,
        settings: dict.user.settings,
        logout: dict.user.logout,
      }}
    />
  )
}

