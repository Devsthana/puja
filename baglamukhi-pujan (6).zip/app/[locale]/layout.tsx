import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { type Locale, i18n } from "@/lib/i18n-config"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ThemeProvider } from "@/components/theme-provider"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import "@/app/globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: {
    default: "Baglamukhi Pujan",
    template: "%s | Baglamukhi Pujan",
  },
  description: "A devotional platform connecting devotees with temples and tirth kshetras across India",
  icons: {
    icon: "/favicon.ico",
  },
}

export async function generateStaticParams() {
  return i18n.locales.map((locale) => ({ locale }))
}

async function getNavItems(locale: Locale) {
  try {
    const response = await fetchAPI("/navigation", {
      populate: "*",
      locale,
    })

    // Check if response has the expected structure
    if (response && response.data && response.data.attributes && response.data.attributes.items) {
      return response.data.attributes.items
    } else {
      console.warn("Navigation data has unexpected structure, using defaults")
      return null
    }
  } catch (error) {
    console.error("Error fetching navigation data:", error)
    return null
  }
}

export default async function RootLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: { locale: Locale }
}) {
  // Default to 'en' if locale is undefined
  const locale = params?.locale || (i18n.defaultLocale as Locale)
  const dict = await getDictionary(locale)
  const navItems = await getNavItems(locale)

  return (
    <html lang={locale} suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light">
          <Header
            locale={locale}
            translations={{
              login: dict.common.login,
              search: dict.common.search,
            }}
            navItems={navItems || undefined}
          />
          <main>{children}</main>
          <Footer locale={locale} />
        </ThemeProvider>
      </body>
    </html>
  )
}

