import Link from "next/link"
import { notFound } from "next/navigation"
import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import { StrapiImage } from "@/components/strapi-image"
import { SeoMetadata } from "@/components/seo-metadata"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PujaBookingForm } from "@/components/puja-booking-form"
import { formatDate } from "@/lib/utils"
import { Calendar, Clock, MapPin, Info } from "lucide-react"

async function getPujaData(slug: string, locale: Locale) {
  const data = await fetchAPI(`/pujas`, {
    filters: {
      slug: {
        $eq: slug,
      },
    },
    populate: "*",
    locale,
  })

  if (!data.data || data.data.length === 0) {
    return null
  }

  return data.data[0]
}

export async function generateStaticParams() {
  try {
    const pujas = await fetchAPI("/pujas", {
      fields: ["slug"],
      populate: "*",
    })

    // If API is not available or returns no data, return an empty array
    if (!pujas || !pujas.data || !Array.isArray(pujas.data)) {
      console.log("No puja data available for static generation, will use dynamic rendering")
      return []
    }

    // Filter out any items that don't have a slug
    const validPujas = pujas.data.filter((puja) => puja && puja.attributes && puja.attributes.slug)

    return validPujas.map((puja: any) => ({
      slug: puja.attributes.slug,
    }))
  } catch (error) {
    console.error("Error generating static params for pujas:", error)
    return []
  }
}

// Add dynamic rendering option
export const dynamicParams = true

export default async function PujaDetailPage({
  params,
}: {
  params: { locale: Locale; slug: string }
}) {
  const { locale, slug } = params
  const dict = await getDictionary(locale)
  const puja = await getPujaData(slug, locale)

  if (!puja) {
    notFound()
  }

  const {
    title = "Puja Details",
    temple = "Temple Name",
    date = new Date().toISOString(),
    time = "10:00 AM",
    price = "₹1,100",
    description = "No description available",
    details = "",
    requirements = [],
    benefits = [],
    options = [],
    templeDescription = "",
    translations = {
      home: "Home",
      pujas: "Pujas",
      details: "Details",
      requirementsTitle: "Requirements",
      benefitsTitle: "Benefits",
      aboutTemple: "About the Temple",
      bookYourPuja: "Book Your Puja",
    },
    seo = {},
  } = puja.attributes || {}

  return (
    <>
      <SeoMetadata
        title={seo?.metaTitle || title}
        description={seo?.metaDescription || description}
        image={puja.attributes.image?.data?.attributes?.url}
        locale={locale}
      />

      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="flex items-center gap-2 text-sm text-gray-600 mb-6">
          <Link href={`/${locale}`} className="hover:text-orange-600">
            {translations?.home || "Home"}
          </Link>
          <span>/</span>
          <Link href={`/${locale}/puja`} className="hover:text-orange-600">
            {translations?.pujas || "Pujas"}
          </Link>
          <span>/</span>
          <span className="text-gray-900 font-medium">{title}</span>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden mb-8">
              <StrapiImage image={puja.attributes.image?.data} alt={title} fill className="object-cover" />
            </div>

            <h1 className="text-2xl md:text-3xl font-bold mb-4">{title}</h1>

            <div className="flex flex-wrap gap-4 mb-6">
              <div className="flex items-center gap-2 text-gray-700">
                <MapPin className="h-5 w-5 text-orange-600" />
                <span>{temple}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <Calendar className="h-5 w-5 text-orange-600" />
                <span>{formatDate(date, locale)}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <Clock className="h-5 w-5 text-orange-600" />
                <span>{time}</span>
              </div>
            </div>

            <p className="text-gray-700 mb-8">{description}</p>

            <Tabs defaultValue="details" className="w-full">
              <TabsList className="bg-orange-50 p-1 rounded-lg">
                <TabsTrigger
                  value="details"
                  className="data-[state=active]:bg-orange-600 data-[state=active]:text-white"
                >
                  {translations?.details || "Details"}
                </TabsTrigger>
                <TabsTrigger
                  value="requirements"
                  className="data-[state=active]:bg-orange-600 data-[state=active]:text-white"
                >
                  {translations?.requirementsTitle || "Requirements"}
                </TabsTrigger>
                <TabsTrigger
                  value="benefits"
                  className="data-[state=active]:bg-orange-600 data-[state=active]:text-white"
                >
                  {translations?.benefitsTitle || "Benefits"}
                </TabsTrigger>
              </TabsList>

              <TabsContent value="details" className="mt-6">
                <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: details || "" }} />
              </TabsContent>

              <TabsContent value="requirements" className="mt-6">
                <ul className="space-y-2">
                  {requirements && requirements.length > 0 ? (
                    requirements.map((req: any, i: number) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="bg-orange-100 text-orange-800 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                          {i + 1}
                        </span>
                        <span>{req.text}</span>
                      </li>
                    ))
                  ) : (
                    <li>No requirements specified</li>
                  )}
                </ul>
              </TabsContent>

              <TabsContent value="benefits" className="mt-6">
                <ul className="space-y-2">
                  {benefits && benefits.length > 0 ? (
                    benefits.map((benefit: any, i: number) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="bg-orange-100 text-orange-800 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                          {i + 1}
                        </span>
                        <span>{benefit.text}</span>
                      </li>
                    ))
                  ) : (
                    <li>No benefits specified</li>
                  )}
                </ul>
              </TabsContent>
            </Tabs>

            {templeDescription && (
              <div className="mt-12">
                <h2 className="text-xl font-bold mb-4">{translations?.aboutTemple || "About the Temple"}</h2>
                <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: templeDescription }} />
              </div>
            )}
          </div>

          <div className="lg:col-span-1">
            <div className="bg-orange-50 rounded-lg p-6 sticky top-24">
              <h2 className="text-xl font-bold mb-6">{translations?.bookYourPuja || "Book Your Puja"}</h2>

              <PujaBookingForm
                options={options || []}
                translations={translations || {}}
                locale={locale}
                pujaId={puja.id}
                pujaTitle={title}
              />

              <div className="flex items-start gap-2 mt-6 text-sm">
                <Info className="h-5 w-5 text-orange-600 flex-shrink-0 mt-0.5" />
                <p className="text-gray-600">
                  {translations?.priceNote || "Price includes all materials required for the puja."}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

