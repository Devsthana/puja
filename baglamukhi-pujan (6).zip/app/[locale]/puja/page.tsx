import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import { PujaCard } from "@/components/puja-card"
import { SeoMetadata } from "@/components/seo-metadata"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

async function getPujaPageData(locale: Locale) {
  try {
    const pageData = await fetchAPI("/puja-page", {
      populate: {
        filterTabs: {
          populate: "*",
        },
        seo: {
          populate: "*",
        },
      },
      locale,
    })

    const pujas = await fetchAPI("/pujas", {
      populate: "*",
      locale,
    })

    return {
      page: pageData?.data?.attributes || { title: "Upcoming Pujas", filterTabs: [], seo: {} },
      pujas: pujas?.data || [],
    }
  } catch (error) {
    console.error("Error fetching puja page data:", error)
    return {
      page: { title: "Upcoming Pujas", filterTabs: [], seo: {} },
      pujas: [],
    }
  }
}

export default async function PujaPage({ params }: { params: { locale: Locale } }) {
  const { locale } = params
  const dict = await getDictionary(locale)
  const { page, pujas } = await getPujaPageData(locale)

  // Default values if data is not available
  const title = page?.title || "Upcoming Pujas"
  const filterTabs = page?.filterTabs || [
    { label: "All", value: "all" },
    { label: "Closing Soon", value: "closing-soon" },
    { label: "This Week", value: "this-week" },
  ]
  const seo = page?.seo || {}

  // Filter pujas based on categories, with safety checks
  const closingSoonPujas = pujas.filter((puja: any) => puja && puja.attributes && puja.attributes.closingSoon === true)

  const thisWeekPujas = pujas.filter((puja: any) => {
    if (!puja || !puja.attributes || !puja.attributes.date) return false

    const pujaDate = new Date(puja.attributes.date)
    const today = new Date()
    const nextWeek = new Date(today)
    nextWeek.setDate(today.getDate() + 7)
    return pujaDate >= today && pujaDate <= nextWeek
  })

  return (
    <>
      <SeoMetadata
        title={seo.metaTitle || "Pujas - Baglamukhi Pujan"}
        description={seo.metaDescription || "Participate in upcoming pujas at various temples across India."}
        image={seo.shareImage?.data?.attributes?.url}
        locale={locale}
      />

      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="bg-orange-600 rounded-lg p-6 md:p-8 mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-white">{title}</h1>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="mb-8 bg-orange-50 p-1 rounded-lg">
            {filterTabs.map((tab: any, i: number) => (
              <TabsTrigger
                key={i}
                value={tab.value}
                className="data-[state=active]:bg-orange-600 data-[state=active]:text-white"
              >
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="closing-soon" className="mt-0">
            {closingSoonPujas.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {closingSoonPujas.map((puja: any) => (
                  <PujaCard key={puja.id} puja={puja} locale={locale} dict={dict} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">No closing soon pujas available at the moment.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="this-week" className="mt-0">
            {thisWeekPujas.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {thisWeekPujas.map((puja: any) => (
                  <PujaCard key={puja.id} puja={puja} locale={locale} dict={dict} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">No pujas scheduled for this week.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="all" className="mt-0">
            {pujas.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pujas.map((puja: any) => (
                  <PujaCard key={puja.id} puja={puja} locale={locale} dict={dict} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">No pujas available at the moment. Please check back later.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </>
  )
}

