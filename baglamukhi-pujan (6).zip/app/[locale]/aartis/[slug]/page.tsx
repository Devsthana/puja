import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"
import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Play, Download } from "lucide-react"

async function getAartiData(slug: string, locale: Locale) {
  try {
    const data = await fetchAPI(`/aartis`, {
      filters: {
        slug: {
          $eq: slug,
        },
      },
      populate: "*",
      locale,
    })

    if (!data.data || data.data.length === 0) {
      return null
    }

    return data.data[0]
  } catch (error) {
    console.error(`Error fetching aarti data for slug ${slug}:`, error)
    return null
  }
}

// Sample aarti data for when API returns nothing
const getSampleAarti = (slug: string) => ({
  id: "sample-1",
  attributes: {
    title: "Baglamukhi Aarti",
    deity: "Maa Baglamukhi",
    duration: "5:30",
    description: "This is the divine aarti of Goddess Baglamukhi, sung with devotion to invoke her blessings.",
    lyrics: `<p>जय बगलामुखी माता, जय बगलामुखी माता।<br>
    पीताम्बर धारिणी, दुष्टों का संहार करने वाली॥<br>
    जय बगलामुखी माता, जय बगलामुखी माता।</p>
    
    <p>पीले वस्त्र पहने, पीले आभूषण धारण किए।<br>
    हाथों में गदा लिए, शत्रुओं का नाश करती हो॥<br>
    जय बगलामुखी माता, जय बगलामुखी माता।</p>`,
    meaning:
      "<p>This aarti praises Goddess Baglamukhi, who is known for her power to paralyze enemies and negative forces. She is depicted wearing yellow clothes and ornaments, holding a club in her hand, which she uses to destroy enemies.</p>",
    audioUrl: "#",
    slug: slug,
  },
})

export default async function AartiDetailPage({
  params,
}: {
  params: { locale: Locale; slug: string }
}) {
  const { locale, slug } = params
  const dict = await getDictionary(locale)
  let aarti = await getAartiData(slug, locale)

  // Use sample data if API returns nothing
  if (!aarti) {
    aarti = getSampleAarti(slug)
  }

  if (!aarti) {
    notFound()
  }

  const {
    title = "Aarti",
    deity = "Deity",
    duration = "0:00",
    description = "No description available",
    lyrics = "",
    meaning = "",
    audioUrl = "#",
  } = aarti.attributes || {}

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="flex items-center gap-2 text-sm text-gray-600 mb-6">
        <Link href={`/${locale}`} className="hover:text-orange-600">
          {dict.common.home}
        </Link>
        <span>/</span>
        <Link href={`/${locale}/aartis`} className="hover:text-orange-600">
          {dict.common.aartis}
        </Link>
        <span>/</span>
        <span className="text-gray-900 font-medium">{title}</span>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">{title}</h1>
          <p className="text-gray-600 mb-6">
            {deity} • {duration}
          </p>

          <p className="text-gray-700 mb-8">{description}</p>

          <div className="bg-orange-50 p-6 rounded-lg mb-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-lg">Listen to Aarti</h3>
                <p className="text-sm text-gray-600">Duration: {duration}</p>
              </div>
              <div className="flex gap-2">
                <Button className="bg-orange-600 hover:bg-orange-700">
                  <Play className="h-4 w-4 mr-2" />
                  {dict.aarti.listen}
                </Button>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  {dict.aarti.download}
                </Button>
              </div>
            </div>
            <div className="relative h-12 bg-white rounded-md overflow-hidden">
              <div className="absolute left-0 top-0 h-full w-1/3 bg-orange-200"></div>
              <div className="absolute left-1/3 top-0 h-full w-1 bg-orange-600"></div>
            </div>
          </div>

          <Tabs defaultValue="lyrics" className="w-full">
            <TabsList className="bg-orange-50 p-1 rounded-lg">
              <TabsTrigger value="lyrics" className="data-[state=active]:bg-orange-600 data-[state=active]:text-white">
                {dict.aarti.lyrics}
              </TabsTrigger>
              <TabsTrigger value="meaning" className="data-[state=active]:bg-orange-600 data-[state=active]:text-white">
                {dict.aarti.meaning}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="lyrics" className="mt-6">
              <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: lyrics || "" }} />
            </TabsContent>

            <TabsContent value="meaning" className="mt-6">
              <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: meaning || "" }} />
            </TabsContent>
          </Tabs>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-orange-50 rounded-lg p-6 sticky top-24">
            <div className="relative h-48 mb-6 rounded-lg overflow-hidden">
              <Image src="/placeholder.svg?height=200&width=300" alt={title} fill className="object-cover" />
            </div>

            <h3 className="text-xl font-bold mb-4">Related Aartis</h3>

            <div className="space-y-4">
              <div className="flex gap-3 items-center">
                <div className="bg-orange-100 rounded-md h-12 w-12 flex-shrink-0 flex items-center justify-center">
                  <Play className="h-5 w-5 text-orange-600" />
                </div>
                <div>
                  <h4 className="font-medium">Ganesh Aarti</h4>
                  <p className="text-xs text-gray-500">4:15</p>
                </div>
              </div>

              <div className="flex gap-3 items-center">
                <div className="bg-orange-100 rounded-md h-12 w-12 flex-shrink-0 flex items-center justify-center">
                  <Play className="h-5 w-5 text-orange-600" />
                </div>
                <div>
                  <h4 className="font-medium">Durga Aarti</h4>
                  <p className="text-xs text-gray-500">5:45</p>
                </div>
              </div>

              <div className="flex gap-3 items-center">
                <div className="bg-orange-100 rounded-md h-12 w-12 flex-shrink-0 flex items-center justify-center">
                  <Play className="h-5 w-5 text-orange-600" />
                </div>
                <div>
                  <h4 className="font-medium">Shiva Aarti</h4>
                  <p className="text-xs text-gray-500">7:10</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

