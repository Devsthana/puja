import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Play } from "lucide-react"

async function getAartisPageData(locale: Locale) {
  try {
    const pageData = await fetchAPI("/aarti-page", {
      populate: {
        seo: {
          populate: "*",
        },
      },
      locale,
    })

    const aartis = await fetchAPI("/aartis", {
      populate: "*",
      locale,
    })

    return {
      page: pageData?.data?.attributes || {
        title: "Aartis",
        subtitle: "Listen to divine aartis from various temples across India",
        seo: {},
      },
      aartis: aartis?.data || [],
    }
  } catch (error) {
    console.error("Error fetching aartis page data:", error)
    return {
      page: {
        title: "Aartis",
        subtitle: "Listen to divine aartis from various temples across India",
        seo: {},
      },
      aartis: [],
    }
  }
}

export default async function AartisPage({ params }: { params: { locale: Locale } }) {
  const { locale } = params
  const dict = await getDictionary(locale)
  const { page, aartis } = await getAartisPageData(locale)

  // Default values if data is not available
  const title = page?.title || "Aartis"
  const subtitle = page?.subtitle || "Listen to divine aartis from various temples across India"

  // Sample aartis for when API returns empty
  const sampleAartis = [
    {
      id: 1,
      attributes: {
        title: "Baglamukhi Aarti",
        deity: "Maa Baglamukhi",
        duration: "5:30",
        slug: "baglamukhi-aarti",
        image: null,
      },
    },
    {
      id: 2,
      attributes: {
        title: "Ganesh Aarti",
        deity: "Lord Ganesha",
        duration: "4:15",
        slug: "ganesh-aarti",
        image: null,
      },
    },
    {
      id: 3,
      attributes: {
        title: "Hanuman Aarti",
        deity: "Lord Hanuman",
        duration: "6:20",
        slug: "hanuman-aarti",
        image: null,
      },
    },
    {
      id: 4,
      attributes: {
        title: "Durga Aarti",
        deity: "Maa Durga",
        duration: "5:45",
        slug: "durga-aarti",
        image: null,
      },
    },
    {
      id: 5,
      attributes: {
        title: "Shiva Aarti",
        deity: "Lord Shiva",
        duration: "7:10",
        slug: "shiva-aarti",
        image: null,
      },
    },
    {
      id: 6,
      attributes: {
        title: "Lakshmi Aarti",
        deity: "Maa Lakshmi",
        duration: "4:50",
        slug: "lakshmi-aarti",
        image: null,
      },
    },
  ]

  // Use sample aartis if API returns empty
  const displayAartis = aartis.length > 0 ? aartis : sampleAartis

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">{title}</h1>
        <p className="text-gray-600">{subtitle}</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayAartis.map((aarti: any) => (
          <Link key={aarti.id} href={`/${locale}/aartis/${aarti.attributes.slug}`}>
            <Card className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative h-48 bg-orange-100">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt={aarti.attributes.title}
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-orange-600 rounded-full p-3 text-white">
                    <Play className="h-8 w-8" />
                  </div>
                </div>
              </div>
              <CardContent className="p-4">
                <h3 className="font-bold text-lg mb-1">{aarti.attributes.title}</h3>
                <p className="text-gray-600 text-sm mb-2">{aarti.attributes.deity}</p>
                <p className="text-xs text-gray-500">{aarti.attributes.duration}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}

