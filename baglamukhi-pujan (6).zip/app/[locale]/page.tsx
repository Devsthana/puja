import Link from "next/link"
import Image from "next/image"
import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { PujaCard } from "@/components/puja-card"
import { CheckCircle } from "lucide-react"

async function getHomePageData(locale: Locale) {
  try {
    const response = await fetchAPI("/homepage", {
      populate: {
        hero: {
          populate: "*",
        },
        trustBadge: {
          populate: "*",
        },
        featuredPujas: {
          populate: {
            pujas: {
              populate: "*",
            },
          },
        },
        features: {
          populate: "*",
        },
        seo: {
          populate: "*",
        },
      },
      locale,
    })

    // Ensure we have a valid data structure
    if (!response || !response.data) {
      console.warn("API returned invalid data structure for homepage")
      return null
    }

    return response.data
  } catch (error) {
    console.error("Error fetching homepage data:", error)
    return null
  }
}

export default async function Home({ params }: { params: { locale: Locale } }) {
  const { locale } = params
  const dict = await getDictionary(locale)
  const data = await getHomePageData(locale)

  // Default data if API fails
  const hero = data?.attributes?.hero || {
    title: dict.home.hero.title,
    subtitle: dict.home.hero.subtitle,
    image: null,
  }

  const trustBadge = data?.attributes?.trustBadge || {
    title: dict.home.trusted.title,
    description: dict.home.trusted.description,
    features: [
      { text: "Authentic rituals performed by experienced pandits" },
      { text: "Live streaming of pujas from sacred temples" },
      { text: "Blessed prasad delivered to your doorstep" },
    ],
  }

  const features = data?.attributes?.features || {
    title: dict.home.features.title,
    items: [
      {
        title: dict.home.features.pujas.title,
        description: dict.home.features.pujas.description,
        icon: "pujas",
      },
      {
        title: dict.home.features.aartis.title,
        description: dict.home.features.aartis.description,
        icon: "aartis",
      },
      {
        title: dict.home.features.mantras.title,
        description: dict.home.features.mantras.description,
        icon: "mantras",
      },
    ],
  }

  const featuredPujas = data?.attributes?.featuredPujas || {
    title: dict.home.upcomingPujas,
    description: dict.home.upcomingPujasDescription,
    pujas: { data: [] },
  }

  // Sample pujas for when API returns empty
  const samplePujas = [
    {
      id: 1,
      attributes: {
        title: "Baglamukhi Puja",
        temple: "Baglamukhi Temple, Kangra",
        date: new Date().toISOString(),
        time: "10:00 AM",
        price: "₹1,100",
        closingSoon: true,
        slug: "baglamukhi-puja",
        image: null,
      },
    },
    {
      id: 2,
      attributes: {
        title: "Maha Mrityunjaya Puja",
        temple: "Kashi Vishwanath Temple",
        date: new Date().toISOString(),
        time: "11:00 AM",
        price: "₹2,100",
        closingSoon: false,
        slug: "maha-mrityunjaya-puja",
        image: null,
      },
    },
    {
      id: 3,
      attributes: {
        title: "Navgraha Shanti Puja",
        temple: "Birla Mandir, Delhi",
        date: new Date().toISOString(),
        time: "09:00 AM",
        price: "₹1,500",
        closingSoon: false,
        slug: "navgraha-shanti-puja",
        image: null,
      },
    },
  ]

  const pujas = featuredPujas.pujas?.data?.length > 0 ? featuredPujas.pujas.data : samplePujas

  return (
    <>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-orange-50 to-white py-12 md:py-20">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid gap-8 md:grid-cols-2 md:gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter">
                <span className="text-orange-600">{hero.title}</span>
              </h1>
              <p className="text-lg text-gray-600 max-w-[600px]">{hero.subtitle}</p>
              <div className="flex flex-wrap gap-4 pt-4">
                <Button className="bg-orange-600 hover:bg-orange-700 text-white">{dict.home.hero.cta}</Button>
                <Button variant="outline">{dict.common.downloadApp}</Button>
              </div>
            </div>
            <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden">
              <Image src="/placeholder.svg?height=400&width=600" alt="Baglamukhi Pujan" fill className="object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Trust Badge Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">{trustBadge.title}</h2>
            <p className="text-gray-600">{trustBadge.description}</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {trustBadge.features.map((feature: any, i: number) => (
              <div key={i} className="flex items-start gap-3 p-4 rounded-lg border border-orange-100 bg-orange-50">
                <CheckCircle className="h-6 w-6 text-orange-600 flex-shrink-0 mt-0.5" />
                <p>{feature.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold">{features.title}</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.items.map((feature: any, i: number) => (
              <div key={i} className="bg-white rounded-lg shadow-md p-6 text-center">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Image src={`/icons/${feature.icon || "default"}.svg`} alt={feature.title} width={32} height={32} />
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Pujas Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-3xl mx-auto mb-8">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">{featuredPujas.title}</h2>
            <p className="text-gray-600">{featuredPujas.description}</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pujas.map((puja: any) => (
              <PujaCard key={puja.id} puja={puja} locale={locale} dict={dict} />
            ))}
          </div>

          <div className="text-center mt-10">
            <Link
              href={`/${locale}/pujas`}
              className="inline-flex h-10 items-center justify-center rounded-md bg-orange-600 px-8 text-sm font-medium text-white shadow transition-colors hover:bg-orange-700 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            >
              {dict.common.viewAll}
            </Link>
          </div>
        </div>
      </section>

      {/* App Download Section */}
      <section className="py-12 bg-orange-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="space-y-4">
              <h2 className="text-2xl md:text-3xl font-bold">Download Our Mobile App</h2>
              <p className="text-gray-600">
                Get the Baglamukhi Pujan app for a seamless experience. Book pujas, listen to aartis, and connect with
                temples on the go.
              </p>
              <div className="flex flex-wrap gap-4 pt-2">
                <a href="#" target="_blank" rel="noopener noreferrer">
                  <Image src="/google-play.svg" alt="Google Play" width={135} height={40} className="h-10 w-auto" />
                </a>
                <a href="#" target="_blank" rel="noopener noreferrer">
                  <Image src="/app-store.svg" alt="App Store" width={120} height={40} className="h-10 w-auto" />
                </a>
              </div>
            </div>
            <div className="relative h-[400px] md:h-[500px]">
              <Image
                src="/placeholder.svg?height=500&width=300"
                alt="Baglamukhi Pujan App"
                fill
                className="object-contain"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

