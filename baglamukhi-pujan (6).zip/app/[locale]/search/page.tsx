import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { SearchResults } from "@/components/search-results"
import { fetchAPI } from "@/lib/api"

interface SearchPageProps {
  params: { locale: Locale }
  searchParams: { q?: string }
}

async function searchContent(query: string, locale: Locale) {
  try {
    // In a real application, you would implement a proper search API
    // This is a simplified example
    const pujas = await fetchAPI("/pujas", {
      filters: {
        title: {
          $containsi: query,
        },
      },
      populate: "*",
      locale,
    })

    const aartis = await fetchAPI("/aartis", {
      filters: {
        title: {
          $containsi: query,
        },
      },
      populate: "*",
      locale,
    })

    const mantras = await fetchAPI("/mantras", {
      filters: {
        title: {
          $containsi: query,
        },
      },
      populate: "*",
      locale,
    })

    const blogs = await fetchAPI("/blogs", {
      filters: {
        title: {
          $containsi: query,
        },
      },
      populate: "*",
      locale,
    })

    return {
      pujas: pujas?.data || [],
      aartis: aartis?.data || [],
      mantras: mantras?.data || [],
      blogs: blogs?.data || [],
    }
  } catch (error) {
    console.error("Error searching content:", error)
    return {
      pujas: [],
      aartis: [],
      mantras: [],
      blogs: [],
    }
  }
}

export default async function SearchPage({ params, searchParams }: SearchPageProps) {
  const { locale } = params
  const query = searchParams.q || ""
  const dict = await getDictionary(locale)

  const results = query
    ? await searchContent(query, locale)
    : {
        pujas: [],
        aartis: [],
        mantras: [],
        blogs: [],
      }

  const totalResults = results.pujas.length + results.aartis.length + results.mantras.length + results.blogs.length

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-2">Search Results</h1>
        {query ? (
          <p className="text-gray-600">
            {totalResults} results found for "{query}"
          </p>
        ) : (
          <p className="text-gray-600">Enter a search term to find content</p>
        )}
      </div>

      <SearchResults
        results={results}
        locale={locale}
        query={query}
        translations={{
          pujas: dict.common.pujas,
          aartis: dict.common.aartis,
          mantras: dict.common.mantras,
          blogs: dict.common.blog,
          noResults: "No results found",
          viewAll: dict.common.viewAll,
        }}
      />
    </div>
  )
}

