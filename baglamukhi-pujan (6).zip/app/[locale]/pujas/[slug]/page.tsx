import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"
import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import { formatDate } from "@/lib/utils"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PujaBookingForm } from "@/components/puja-booking-form"
import { Calendar, Clock, MapPin, Info } from "lucide-react"

async function getPujaData(slug: string, locale: Locale) {
  try {
    const data = await fetchAPI(`/pujas`, {
      filters: {
        slug: {
          $eq: slug,
        },
      },
      populate: "*",
      locale,
    })

    if (!data.data || data.data.length === 0) {
      return null
    }

    return data.data[0]
  } catch (error) {
    console.error(`Error fetching puja data for slug ${slug}:`, error)
    return null
  }
}

// Sample puja data for when API returns nothing
const getSamplePuja = (slug: string) => ({
  id: "sample-1",
  attributes: {
    title: "Baglamukhi Puja",
    temple: "Baglamukhi Temple, Kangra",
    date: new Date().toISOString(),
    time: "10:00 AM",
    price: "₹1,100",
    description:
      "Baglamukhi Puja is performed to overcome enemies, win court cases, and remove obstacles. The goddess Baglamukhi is known for her power to paralyze enemies and negative forces.",
    details:
      "<p>Baglamukhi is the eighth Mahavidya in the list of ten Mahavidyas. She is also known as Pitambara Maa (the yellow-clad goddess). This puja is performed with specific rituals and mantras to invoke the blessings of Goddess Baglamukhi.</p><p>The puja includes havan, recitation of mantras, and offerings to the deity. It is performed by experienced pandits who are well-versed in the rituals of Baglamukhi Puja.</p>",
    requirements: [
      { text: "Yellow flowers" },
      { text: "Yellow clothes" },
      { text: "Turmeric" },
      { text: "Sweets (preferably yellow)" },
      { text: "Ghee" },
    ],
    benefits: [
      { text: "Protection from enemies and negative forces" },
      { text: "Success in legal matters and disputes" },
      { text: "Removal of obstacles and hurdles" },
      { text: "Enhanced mental strength and clarity" },
      { text: "Protection from black magic and evil eye" },
    ],
    options: [
      { name: "Basic Package", price: "₹1,100" },
      { name: "Standard Package", price: "₹2,100" },
      { name: "Premium Package", price: "₹3,100" },
    ],
    templeDescription:
      "<p>Baglamukhi Temple in Kangra is one of the most revered temples dedicated to Goddess Baglamukhi. The temple is known for its powerful energy and the efficacy of prayers offered here. It is visited by thousands of devotees seeking the blessings of the goddess.</p>",
    slug: slug,
  },
})

export default async function PujaDetailPage({
  params,
}: {
  params: { locale: Locale; slug: string }
}) {
  const { locale, slug } = params
  const dict = await getDictionary(locale)
  let puja = await getPujaData(slug, locale)

  // Use sample data if API returns nothing
  if (!puja) {
    puja = getSamplePuja(slug)
  }

  if (!puja) {
    notFound()
  }

  const {
    title = "Puja Details",
    temple = "Temple Name",
    date = new Date().toISOString(),
    time = "10:00 AM",
    price = "₹1,100",
    description = "No description available",
    details = "",
    requirements = [],
    benefits = [],
    options = [],
    templeDescription = "",
  } = puja.attributes || {}

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="flex items-center gap-2 text-sm text-gray-600 mb-6">
        <Link href={`/${locale}`} className="hover:text-orange-600">
          {dict.common.home}
        </Link>
        <span>/</span>
        <Link href={`/${locale}/pujas`} className="hover:text-orange-600">
          {dict.common.pujas}
        </Link>
        <span>/</span>
        <span className="text-gray-900 font-medium">{title}</span>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden mb-8">
            <Image src="/placeholder.svg?height=400&width=800" alt={title} fill className="object-cover" />
          </div>

          <h1 className="text-2xl md:text-3xl font-bold mb-4">{title}</h1>

          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex items-center gap-2 text-gray-700">
              <MapPin className="h-5 w-5 text-orange-600" />
              <span>{temple}</span>
            </div>
            <div className="flex items-center gap-2 text-gray-700">
              <Calendar className="h-5 w-5 text-orange-600" />
              <span>{formatDate(date, locale)}</span>
            </div>
            <div className="flex items-center gap-2 text-gray-700">
              <Clock className="h-5 w-5 text-orange-600" />
              <span>{time}</span>
            </div>
          </div>

          <p className="text-gray-700 mb-8">{description}</p>

          <Tabs defaultValue="details" className="w-full">
            <TabsList className="bg-orange-50 p-1 rounded-lg">
              <TabsTrigger value="details" className="data-[state=active]:bg-orange-600 data-[state=active]:text-white">
                {dict.puja.details}
              </TabsTrigger>
              <TabsTrigger
                value="requirements"
                className="data-[state=active]:bg-orange-600 data-[state=active]:text-white"
              >
                {dict.puja.requirements}
              </TabsTrigger>
              <TabsTrigger
                value="benefits"
                className="data-[state=active]:bg-orange-600 data-[state=active]:text-white"
              >
                {dict.puja.benefits}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="mt-6">
              <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: details || "" }} />
            </TabsContent>

            <TabsContent value="requirements" className="mt-6">
              <ul className="space-y-2">
                {requirements && requirements.length > 0 ? (
                  requirements.map((req: any, i: number) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="bg-orange-100 text-orange-800 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span>{req.text}</span>
                    </li>
                  ))
                ) : (
                  <li>No requirements specified</li>
                )}
              </ul>
            </TabsContent>

            <TabsContent value="benefits" className="mt-6">
              <ul className="space-y-2">
                {benefits && benefits.length > 0 ? (
                  benefits.map((benefit: any, i: number) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="bg-orange-100 text-orange-800 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span>{benefit.text}</span>
                    </li>
                  ))
                ) : (
                  <li>No benefits specified</li>
                )}
              </ul>
            </TabsContent>
          </Tabs>

          {templeDescription && (
            <div className="mt-12">
              <h2 className="text-xl font-bold mb-4">{dict.puja.aboutTemple}</h2>
              <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: templeDescription }} />
            </div>
          )}
        </div>

        <div className="lg:col-span-1">
          <div className="bg-orange-50 rounded-lg p-6 sticky top-24">
            <h2 className="text-xl font-bold mb-6">{dict.puja.bookYourPuja}</h2>

            <PujaBookingForm options={options || []} locale={locale} pujaId={puja.id} pujaTitle={title} dict={dict} />

            <div className="flex items-start gap-2 mt-6 text-sm">
              <Info className="h-5 w-5 text-orange-600 flex-shrink-0 mt-0.5" />
              <p className="text-gray-600">{dict.puja.priceNote}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

