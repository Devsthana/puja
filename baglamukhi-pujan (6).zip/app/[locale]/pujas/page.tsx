import type { Locale } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"
import { fetchAPI } from "@/lib/api"
import { PujaCard } from "@/components/puja-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

async function getPujasPageData(locale: Locale) {
  try {
    const pageData = await fetchAPI("/puja-page", {
      populate: {
        seo: {
          populate: "*",
        },
      },
      locale,
    })

    const pujas = await fetchAPI("/pujas", {
      populate: "*",
      locale,
    })

    return {
      page: pageData?.data?.attributes || {
        title: "Upcoming Pujas",
        subtitle: "Book Pujas in your and your family's name at renowned temples in India",
        filterTabs: [],
        seo: {},
      },
      pujas: pujas?.data || [],
    }
  } catch (error) {
    console.error("Error fetching pujas page data:", error)
    return {
      page: {
        title: "Upcoming Pujas",
        subtitle: "Book Pujas in your and your family's name at renowned temples in India",
        filterTabs: [],
        seo: {},
      },
      pujas: [],
    }
  }
}

export default async function PujasPage({ params }: { params: { locale: Locale } }) {
  const { locale } = params
  const dict = await getDictionary(locale)
  const { page, pujas } = await getPujasPageData(locale)

  // Default values if data is not available
  const title = page?.title || "Upcoming Pujas"
  const subtitle = page?.subtitle || "Book Pujas in your and your family's name at renowned temples in India"
  const filterTabs = page?.filterTabs || [
    { label: "All", value: "all" },
    { label: "Closing Soon", value: "closing-soon" },
    { label: "This Week", value: "this-week" },
  ]

  // Sample pujas for when API returns empty
  const samplePujas = [
    {
      id: 1,
      attributes: {
        title: "Baglamukhi Puja",
        temple: "Baglamukhi Temple, Kangra",
        date: new Date().toISOString(),
        time: "10:00 AM",
        price: "₹1,100",
        closingSoon: true,
        slug: "baglamukhi-puja",
        image: null,
      },
    },
    {
      id: 2,
      attributes: {
        title: "Maha Mrityunjaya Puja",
        temple: "Kashi Vishwanath Temple",
        date: new Date().toISOString(),
        time: "11:00 AM",
        price: "₹2,100",
        closingSoon: false,
        slug: "maha-mrityunjaya-puja",
        image: null,
      },
    },
    {
      id: 3,
      attributes: {
        title: "Navgraha Shanti Puja",
        temple: "Birla Mandir, Delhi",
        date: new Date().toISOString(),
        time: "09:00 AM",
        price: "₹1,500",
        closingSoon: false,
        slug: "navgraha-shanti-puja",
        image: null,
      },
    },
  ]

  // Use sample pujas if API returns empty
  const displayPujas = pujas.length > 0 ? pujas : samplePujas

  // Filter pujas based on categories with proper null checks
  const closingSoonPujas = displayPujas.filter(
    (puja: any) => puja && puja.attributes && puja.attributes.closingSoon === true,
  )

  const thisWeekPujas = displayPujas.filter((puja: any) => {
    if (!puja || !puja.attributes || !puja.attributes.date) return false

    const pujaDate = new Date(puja.attributes.date)
    const today = new Date()
    const nextWeek = new Date(today)
    nextWeek.setDate(today.getDate() + 7)
    return pujaDate >= today && pujaDate <= nextWeek
  })

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">{title}</h1>
        <p className="text-gray-600">{subtitle}</p>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-8 bg-orange-50 p-1 rounded-lg">
          {filterTabs.map((tab: any, i: number) => (
            <TabsTrigger
              key={i}
              value={tab.value}
              className="data-[state=active]:bg-orange-600 data-[state=active]:text-white"
            >
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="closing-soon" className="mt-0">
          {closingSoonPujas.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {closingSoonPujas.map((puja: any) => (
                <PujaCard key={puja.id} puja={puja} locale={locale} dict={dict} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">No closing soon pujas available at the moment.</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="this-week" className="mt-0">
          {thisWeekPujas.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {thisWeekPujas.map((puja: any) => (
                <PujaCard key={puja.id} puja={puja} locale={locale} dict={dict} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">No pujas scheduled for this week.</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="all" className="mt-0">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayPujas.map((puja: any) => (
              <PujaCard key={puja.id} puja={puja} locale={locale} dict={dict} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

