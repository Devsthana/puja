export async function fetchAPI(path: string, options = {}) {
  try {
    const defaultOptions = {
      headers: {
        "Content-Type": "application/json",
      },
    }

    const mergedOptions = {
      ...defaultOptions,
      ...options,
    }

    const apiUrl = process.env.STRAPI_URL || "https://cms.baglamukhi.co.in"
    const response = await fetch(`${apiUrl}/api${path}`, mergedOptions)

    if (!response.ok) {
      console.warn(`API warning: ${response.status} for path ${path}`)
      // Return empty data instead of throwing an error
      return { data: [] }
    }

    const data = await response.json()
    return data
  } catch (error) {
    console.error("Error fetching from Strapi API:", error)
    // Return empty data instead of throwing an error
    return { data: [] }
  }
}

