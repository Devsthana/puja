import "server-only"
import type { Locale } from "./i18n-config"

// Define the dictionaries with proper type safety
const dictionaries = {
  en: () => import("./dictionaries/en.json").then((module) => module.default),
  hi: () => import("./dictionaries/hi.json").then((module) => module.default),
  sa: () => import("./dictionaries/sa.json").then((module) => module.default),
} as const

// Make sure we're handling the locale correctly
export const getDictionary = async (locale: Locale) => {
  // Ensure we have a valid locale, defaulting to 'en' if not
  const validLocale = (Object.keys(dictionaries).includes(locale) ? locale : "en") as keyof typeof dictionaries
  return dictionaries[validLocale]()
}

