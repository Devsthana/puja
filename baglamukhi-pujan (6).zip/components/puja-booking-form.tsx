"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import type { Locale } from "@/lib/i18n-config"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

interface PujaBookingFormProps {
  options: any[]
  locale: Locale
  pujaId: string
  pujaTitle: string
  dict: any
}

export function PujaBookingForm({ options, locale, pujaId, pujaTitle, dict }: PujaBookingFormProps) {
  const router = useRouter()
  const [selectedOption, setSelectedOption] = useState("")
  const [quantity, setQuantity] = useState(1)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      setLoading(false)
      // Redirect to success page or show success message
      alert("Booking successful!")
    }, 1500)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="package">Select Package</Label>
        <Select value={selectedOption} onValueChange={setSelectedOption} required>
          <SelectTrigger id="package">
            <SelectValue placeholder="Select a package" />
          </SelectTrigger>
          <SelectContent>
            {options.map((option, i) => (
              <SelectItem key={i} value={option.name}>
                {option.name} - {option.price}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="quantity">Quantity</Label>
        <div className="flex items-center">
          <Button
            type="button"
            variant="outline"
            size="icon"
            className="h-9 w-9 rounded-r-none"
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
          >
            -
          </Button>
          <Input
            id="quantity"
            type="number"
            min="1"
            value={quantity}
            onChange={(e) => setQuantity(Number.parseInt(e.target.value) || 1)}
            className="h-9 rounded-none text-center"
          />
          <Button
            type="button"
            variant="outline"
            size="icon"
            className="h-9 w-9 rounded-l-none"
            onClick={() => setQuantity(quantity + 1)}
          >
            +
          </Button>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="name">Your Name</Label>
        <Input id="name" required />
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input id="email" type="email" required />
      </div>

      <div className="space-y-2">
        <Label htmlFor="phone">Phone Number</Label>
        <Input id="phone" required />
      </div>

      <div className="space-y-2">
        <Label htmlFor="note">Special Instructions (Optional)</Label>
        <Textarea id="note" />
      </div>

      <Button type="submit" className="w-full bg-orange-600 hover:bg-orange-700" disabled={loading}>
        {loading ? "Processing..." : dict.common.bookNow}
      </Button>
    </form>
  )
}

