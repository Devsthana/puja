"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import type { Locale } from "@/lib/i18n-config"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

interface SearchBarProps {
  locale: Locale
}

export function SearchBar({ locale }: SearchBarProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/${locale}/search?q=${encodeURIComponent(searchQuery.trim())}`)
    }
  }

  return (
    <form onSubmit={handleSearch} className="flex w-full max-w-lg mx-auto">
      <div className="relative flex-grow">
        <Input
          type="text"
          placeholder="Search for pujas, mantras, temples..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pr-10 w-full"
        />
        <Button type="submit" variant="ghost" size="icon" className="absolute right-0 top-0 h-full">
          <Search className="h-4 w-4" />
        </Button>
      </div>
    </form>
  )
}

