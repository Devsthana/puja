import type { Locale } from "@/lib/i18n-config"

interface SeoMetadataProps {
  title: string
  description: string
  image?: string
  locale: Locale
}

export function SeoMetadata({ title, description, image, locale }: SeoMetadataProps) {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://baglamukhipujan.com"
  const fullImageUrl = image?.startsWith("http")
    ? image
    : image
      ? `${process.env.NEXT_PUBLIC_STRAPI_API_URL}${image}`
      : `${siteUrl}/og-image.jpg`

  return (
    <>
      <title>{title}</title>
      <meta name="description" content={description} />

      {/* Open Graph */}
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={fullImageUrl} />
      <meta property="og:url" content={siteUrl} />
      <meta property="og:type" content="website" />
      <meta property="og:locale" content={locale} />

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={fullImageUrl} />

      {/* Canonical and alternate language links */}
      <link rel="canonical" href={`${siteUrl}/${locale}`} />
      <link rel="alternate" href={`${siteUrl}/en`} hrefLang="en" />
      <link rel="alternate" href={`${siteUrl}/hi`} hrefLang="hi" />
      <link rel="alternate" href={`${siteUrl}/sa`} hrefLang="sa" />
    </>
  )
}

