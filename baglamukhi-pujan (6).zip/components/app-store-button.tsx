"use client"

import Image from "next/image"
import Link from "next/link"
import { usePathname } from "next/navigation"

interface AppStoreButtonProps {
  href: string
  type: "google" | "apple"
  alt: string
}

export function AppStoreButton({ href, type, alt }: AppStoreButtonProps) {
  const pathname = usePathname()
  const locale = pathname.split("/")[1] || "en"

  const imageSrc = type === "google" ? `/${locale}/google-play.svg` : `/${locale}/app-store.svg`

  return (
    <Link href={href} target="_blank" rel="noopener noreferrer">
      <Image
        src={imageSrc || "/placeholder.svg"}
        alt={alt}
        width={type === "google" ? 135 : 120}
        height={40}
        className="h-10 w-auto"
        onError={(e) => {
          // Fallback to placeholder if image fails to load
          e.currentTarget.src = "/placeholder.svg?height=40&width=120"
        }}
      />
    </Link>
  )
}

