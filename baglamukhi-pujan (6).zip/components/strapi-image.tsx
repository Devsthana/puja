import Image, { type ImageProps } from "next/image"

interface StrapiImageProps extends Omit<ImageProps, "src"> {
  image: any
}

export function StrapiImage({ image, alt, ...props }: StrapiImageProps) {
  if (!image) {
    // Return a placeholder image with the correct dimensions
    return (
      <Image
        src="/placeholder.svg"
        alt={alt || "Placeholder"}
        width={props.width || 800}
        height={props.height || 600}
        {...props}
      />
    )
  }

  const { url, width, height, alternativeText } = image.attributes
  const imageUrl = process.env.NEXT_PUBLIC_STRAPI_API_URL
    ? `${process.env.NEXT_PUBLIC_STRAPI_API_URL}${url}`
    : url && url.startsWith("/")
      ? `https://cms.baglamukhi.co.in${url}`
      : url && url.startsWith("http")
        ? url
        : `/placeholder.svg?width=${width || 800}&height=${height || 600}`

  return (
    <Image
      src={imageUrl || "/placeholder.svg"}
      alt={alt || alternativeText || "Image"}
      width={props.width || width || 800}
      height={props.height || height || 600}
      {...props}
    />
  )
}

