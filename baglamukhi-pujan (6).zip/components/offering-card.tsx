import Link from "next/link"
import type { Locale } from "@/lib/i18n-config"
import { StrapiImage } from "@/components/strapi-image"
import { Badge } from "@/components/ui/badge"

interface OfferingCardProps {
  offering: any
  locale: Locale
  dict: any
  featured?: boolean
}

export function OfferingCard({ offering, locale, dict, featured = false }: OfferingCardProps) {
  if (!offering || !offering.attributes) {
    return null // Don't render anything if offering data is missing
  }

  const {
    slug = "offering",
    title = "Offering",
    temple = "Temple",
    price = "₹1,100",
    shortDescription = "No description available",
    translations = {
      viewDetails: "View Details",
    },
  } = offering.attributes

  return (
    <div
      className={`bg-white rounded-lg shadow-md overflow-hidden border border-gray-100 hover:shadow-lg transition-shadow ${featured ? "ring-2 ring-orange-200" : ""}`}
    >
      <div className="relative h-48">
        <StrapiImage image={offering.attributes.image?.data} alt={title} fill className="object-cover" />
        {featured && (
          <div className="absolute top-3 right-3">
            <Badge className="bg-orange-600 hover:bg-orange-600">Featured</Badge>
          </div>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-bold text-lg mb-2 line-clamp-1">{title}</h3>

        <div className="flex items-center text-sm text-gray-600 mb-3">
          <span className="line-clamp-1">{temple}</span>
        </div>

        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{shortDescription}</p>

        <div className="flex items-center justify-between">
          <div className="font-bold text-orange-600">{price}</div>
          <Link
            href={`/${locale}/offerings/${slug}`}
            className="text-orange-600 hover:text-orange-700 text-sm font-medium transition-colors"
          >
            {translations.viewDetails || "View Details"} →
          </Link>
        </div>
      </div>
    </div>
  )
}

