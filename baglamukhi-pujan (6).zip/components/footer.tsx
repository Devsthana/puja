import Link from "next/link"
import Image from "next/image"
import type { Locale } from "@/lib/i18n-config"
import { fetchAPI } from "@/lib/api"
import { Facebook, Instagram, Twitter, Youtube } from "lucide-react"
import { i18n } from "@/lib/i18n-config"
import { getDictionary } from "@/lib/dictionaries"

interface FooterProps {
  locale: Locale
}

// Default footer data to use when API fails
const defaultFooterData = {
  columns: [
    {
      title: "Quick Links",
      links: [
        { text: "Home", url: "/" },
        { text: "Pujas", url: "/pujas" },
        { text: "Aartis", url: "/aartis" },
        { text: "Mantras", url: "/mantras" },
        { text: "Temples", url: "/temples" },
        { text: "Blog", url: "/blog" },
      ],
    },
    {
      title: "Information",
      links: [
        { text: "About Us", url: "/about" },
        { text: "Contact", url: "/contact" },
        { text: "FAQ", url: "/faq" },
        { text: "Privacy Policy", url: "/privacy" },
        { text: "Terms of Service", url: "/terms" },
      ],
    },
  ],
  socialMedia: [
    { platform: "facebook", url: "#" },
    { platform: "instagram", url: "#" },
    { platform: "twitter", url: "#" },
    { platform: "youtube", url: "#" },
  ],
  contactInfo: {
    address: "123 Temple Street, New Delhi, India",
    phone: "+91 98765 43210",
    email: "info@baglamukhipujan.com",
    description: "Connect with us for spiritual guidance and temple services.",
  },
  copyright: "© 2023 Baglamukhi Pujan. All rights reserved.",
  appLinks: {
    googlePlay: "#",
    appStore: "#",
  },
}

async function getFooterData(locale: Locale = i18n.defaultLocale as Locale) {
  try {
    const response = await fetchAPI("/footer", {
      populate: "*",
      locale,
    })

    // Check if response has the expected structure
    if (response && response.data && response.data.attributes) {
      return response.data.attributes
    }

    console.warn("Footer data has unexpected structure, using defaults")
    return defaultFooterData
  } catch (error) {
    console.error("Error fetching footer data:", error)
    return defaultFooterData
  }
}

export async function Footer({ locale = i18n.defaultLocale as Locale }: FooterProps) {
  const footer = await getFooterData(locale)
  const dict = await getDictionary(locale)
  const { columns, socialMedia, contactInfo, copyright, appLinks } = footer

  const getSocialIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case "facebook":
        return <Facebook className="h-5 w-5" />
      case "instagram":
        return <Instagram className="h-5 w-5" />
      case "twitter":
        return <Twitter className="h-5 w-5" />
      case "youtube":
        return <Youtube className="h-5 w-5" />
      default:
        return null
    }
  }

  return (
    <footer className="bg-orange-50 border-t border-orange-100">
      <div className="container mx-auto px-4 py-12 md:py-16">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {columns && columns.length > 0 ? (
            columns.map((column: any, i: number) => (
              <div key={i} className="space-y-4">
                <h3 className="text-lg font-semibold">{column.title}</h3>
                <ul className="space-y-2">
                  {column.links &&
                    column.links.map((link: any, j: number) => (
                      <li key={j}>
                        <Link
                          href={`/${locale}${link.url}`}
                          className="text-gray-600 hover:text-orange-600 transition-colors"
                        >
                          {link.text}
                        </Link>
                      </li>
                    ))}
                </ul>
              </div>
            ))
          ) : (
            // Default columns if none are provided
            <>
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">{dict.common.pujas}</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href={`/${locale}/pujas`} className="text-gray-600 hover:text-orange-600 transition-colors">
                      {dict.common.pujas}
                    </Link>
                  </li>
                  <li>
                    <Link href={`/${locale}/aartis`} className="text-gray-600 hover:text-orange-600 transition-colors">
                      {dict.common.aartis}
                    </Link>
                  </li>
                  <li>
                    <Link href={`/${locale}/mantras`} className="text-gray-600 hover:text-orange-600 transition-colors">
                      {dict.common.mantras}
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">{dict.common.about}</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href={`/${locale}/about`} className="text-gray-600 hover:text-orange-600 transition-colors">
                      {dict.common.about}
                    </Link>
                  </li>
                  <li>
                    <Link href={`/${locale}/contact`} className="text-gray-600 hover:text-orange-600 transition-colors">
                      {dict.common.contact}
                    </Link>
                  </li>
                </ul>
              </div>
            </>
          )}

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">{dict.contact.getInTouch}</h3>
            <address className="not-italic text-gray-600 space-y-2">
              <p>{contactInfo?.address || "123 Temple Street, New Delhi, India"}</p>
              <p>
                <a
                  href={`tel:${contactInfo?.phone || "+91 98765 43210"}`}
                  className="hover:text-orange-600 transition-colors"
                >
                  {contactInfo?.phone || "+91 98765 43210"}
                </a>
              </p>
              <p>
                <a
                  href={`mailto:${contactInfo?.email || "info@baglamukhipujan.com"}`}
                  className="hover:text-orange-600 transition-colors"
                >
                  {contactInfo?.email || "info@baglamukhipujan.com"}
                </a>
              </p>
            </address>

            <p className="text-gray-600">
              {contactInfo?.description || "Connect with us for spiritual guidance and temple services."}
            </p>

            <div className="flex space-x-4 pt-2">
              {socialMedia && socialMedia.length > 0 ? (
                socialMedia.map((social: any, i: number) => (
                  <a
                    key={i}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 hover:text-orange-600 transition-colors"
                    aria-label={social.platform}
                  >
                    {getSocialIcon(social.platform)}
                  </a>
                ))
              ) : (
                // Default social media icons if none are provided
                <>
                  <a href="#" className="text-gray-600 hover:text-orange-600 transition-colors" aria-label="Facebook">
                    <Facebook className="h-5 w-5" />
                  </a>
                  <a href="#" className="text-gray-600 hover:text-orange-600 transition-colors" aria-label="Instagram">
                    <Instagram className="h-5 w-5" />
                  </a>
                  <a href="#" className="text-gray-600 hover:text-orange-600 transition-colors" aria-label="Twitter">
                    <Twitter className="h-5 w-5" />
                  </a>
                </>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">{dict.common.downloadApp}</h3>
            <div className="flex flex-col space-y-3">
              <a href={appLinks?.googlePlay || "#"} target="_blank" rel="noopener noreferrer">
                <Image src="/google-play.svg" alt="Google Play" width={135} height={40} className="h-10 w-auto" />
              </a>
              <a href={appLinks?.appStore || "#"} target="_blank" rel="noopener noreferrer">
                <Image src="/app-store.svg" alt="App Store" width={120} height={40} className="h-10 w-auto" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-orange-100 text-center text-gray-600 text-sm">
          <p>{copyright || "© 2023 Baglamukhi Pujan. All rights reserved."}</p>
        </div>
      </div>
    </footer>
  )
}

