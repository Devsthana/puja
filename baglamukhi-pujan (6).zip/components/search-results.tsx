"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import type { Locale } from "@/lib/i18n-config"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"

interface SearchResultsProps {
  results: {
    pujas: any[]
    aartis: any[]
    mantras: any[]
    blogs: any[]
  }
  locale: Locale
  query: string
  translations: {
    pujas: string
    aartis: string
    mantras: string
    blogs: string
    noResults: string
    viewAll: string
  }
}

export function SearchResults({ results, locale, query, translations }: SearchResultsProps) {
  const [activeTab, setActiveTab] = useState("all")
  const totalResults = results.pujas.length + results.aartis.length + results.mantras.length + results.blogs.length

  if (!query) {
    return (
      <div className="text-center py-12 bg-gray-50 rounded-lg">
        <p className="text-gray-500">Enter a search term to find content</p>
      </div>
    )
  }

  if (totalResults === 0) {
    return (
      <div className="text-center py-12 bg-gray-50 rounded-lg">
        <p className="text-gray-500">
          {translations.noResults} for "{query}"
        </p>
      </div>
    )
  }

  return (
    <Tabs defaultValue="all" onValueChange={setActiveTab}>
      <TabsList className="mb-8">
        <TabsTrigger value="all">All ({totalResults})</TabsTrigger>
        {results.pujas.length > 0 && (
          <TabsTrigger value="pujas">
            {translations.pujas} ({results.pujas.length})
          </TabsTrigger>
        )}
        {results.aartis.length > 0 && (
          <TabsTrigger value="aartis">
            {translations.aartis} ({results.aartis.length})
          </TabsTrigger>
        )}
        {results.mantras.length > 0 && (
          <TabsTrigger value="mantras">
            {translations.mantras} ({results.mantras.length})
          </TabsTrigger>
        )}
        {results.blogs.length > 0 && (
          <TabsTrigger value="blogs">
            {translations.blogs} ({results.blogs.length})
          </TabsTrigger>
        )}
      </TabsList>

      <TabsContent value="all">
        {results.pujas.length > 0 && (
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">{translations.pujas}</h2>
              <Link href={`/${locale}/pujas?q=${query}`} className="text-orange-600 hover:text-orange-700">
                {translations.viewAll}
              </Link>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.pujas.slice(0, 3).map((puja) => (
                <Link key={puja.id} href={`/${locale}/pujas/${puja.attributes.slug}`}>
                  <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative h-40">
                      <Image
                        src="/placeholder.svg?height=160&width=320"
                        alt={puja.attributes.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-bold">{puja.attributes.title}</h3>
                      <p className="text-sm text-gray-600 mt-1">{puja.attributes.temple}</p>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}

        {results.aartis.length > 0 && (
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">{translations.aartis}</h2>
              <Link href={`/${locale}/aartis?q=${query}`} className="text-orange-600 hover:text-orange-700">
                {translations.viewAll}
              </Link>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.aartis.slice(0, 3).map((aarti) => (
                <Link key={aarti.id} href={`/${locale}/aartis/${aarti.attributes.slug}`}>
                  <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative h-40">
                      <Image
                        src="/placeholder.svg?height=160&width=320"
                        alt={aarti.attributes.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-bold">{aarti.attributes.title}</h3>
                      <p className="text-sm text-gray-600 mt-1">{aarti.attributes.deity}</p>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Similar sections for mantras and blogs */}
      </TabsContent>

      <TabsContent value="pujas">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {results.pujas.map((puja) => (
            <Link key={puja.id} href={`/${locale}/pujas/${puja.attributes.slug}`}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative h-40">
                  <Image
                    src="/placeholder.svg?height=160&width=320"
                    alt={puja.attributes.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-bold">{puja.attributes.title}</h3>
                  <p className="text-sm text-gray-600 mt-1">{puja.attributes.temple}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </TabsContent>

      {/* Similar TabsContent for aartis, mantras, and blogs */}
    </Tabs>
  )
}

