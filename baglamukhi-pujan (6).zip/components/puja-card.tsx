import Link from "next/link"
import Image from "next/image"
import type { Locale } from "@/lib/i18n-config"
import { formatDate } from "@/lib/utils"
import { Calendar, Clock, MapPin } from "lucide-react"

interface PujaCardProps {
  puja: any
  locale: Locale
  dict: any
}

export function PujaCard({ puja, locale, dict }: PujaCardProps) {
  if (!puja || !puja.attributes) {
    return null // Don't render anything if puja data is missing
  }

  const {
    slug = "puja",
    title = "Puja",
    temple = "Temple",
    date = new Date().toISOString(),
    time = "10:00 AM",
    price = "₹1,100",
    closingSoon = false,
  } = puja.attributes

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-100 hover:shadow-lg transition-shadow">
      <div className="relative h-48">
        <Image src="/placeholder.svg" alt={title} fill className="object-cover" />
        {closingSoon && (
          <div className="absolute top-3 right-3 bg-red-600 text-white text-xs font-medium px-2 py-1 rounded">
            {dict.common.closingSoon}
          </div>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-bold text-lg mb-2 line-clamp-1">{title}</h3>

        <div className="space-y-2 mb-4">
          <div className="flex items-center text-sm text-gray-600">
            <MapPin className="h-4 w-4 mr-2 text-orange-600 flex-shrink-0" />
            <span className="line-clamp-1">{temple}</span>
          </div>

          <div className="flex items-center text-sm text-gray-600">
            <Calendar className="h-4 w-4 mr-2 text-orange-600 flex-shrink-0" />
            <span>{formatDate(date, locale)}</span>
          </div>

          <div className="flex items-center text-sm text-gray-600">
            <Clock className="h-4 w-4 mr-2 text-orange-600 flex-shrink-0" />
            <span>{time}</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="font-bold text-orange-600">{price}</div>
          <Link
            href={`/${locale}/pujas/${slug}`}
            className="bg-orange-600 hover:bg-orange-700 text-white text-sm font-medium px-4 py-2 rounded-md transition-colors"
          >
            {dict.common.bookNow}
          </Link>
        </div>
      </div>
    </div>
  )
}

