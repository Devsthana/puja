"use client"

import { useState } from "react"
import type { Locale } from "@/lib/i18n-config"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, MapPin, Package, User, Settings, LogOut } from "lucide-react"

interface Booking {
  id: string
  title: string
  temple: string
  date: string
  time: string
  status: string
  price: string
}

interface UserDashboardClientProps {
  locale: Locale
  bookings: Booking[]
  translations: {
    dashboard: string
    myBookings: string
    profile: string
    settings: string
    logout: string
  }
}

export function UserDashboardClient({ locale, bookings, translations }: UserDashboardClientProps) {
  const [activeTab, setActiveTab] = useState("bookings")

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <h1 className="text-2xl md:text-3xl font-bold mb-8">{translations.dashboard}</h1>

      <div className="grid md:grid-cols-4 gap-6">
        <div className="md:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="flex flex-col items-center mb-6">
              <div className="relative h-24 w-24 rounded-full overflow-hidden mb-4">
                <Image
                  src="/placeholder.svg?height=96&width=96"
                  alt="User Avatar"
                  width={96}
                  height={96}
                  className="object-cover"
                />
              </div>
              <h2 className="text-xl font-bold">John Doe</h2>
              <p className="text-gray-600">john.doe@example.com</p>
            </div>

            <nav className="space-y-2">
              <button
                className={`flex items-center gap-2 w-full p-2 rounded-md ${activeTab === "bookings" ? "bg-orange-100 text-orange-600" : "hover:bg-gray-100"}`}
                onClick={() => setActiveTab("bookings")}
              >
                <Package className="h-5 w-5" />
                <span>{translations.myBookings}</span>
              </button>
              <button
                className={`flex items-center gap-2 w-full p-2 rounded-md ${activeTab === "profile" ? "bg-orange-100 text-orange-600" : "hover:bg-gray-100"}`}
                onClick={() => setActiveTab("profile")}
              >
                <User className="h-5 w-5" />
                <span>{translations.profile}</span>
              </button>
              <button
                className={`flex items-center gap-2 w-full p-2 rounded-md ${activeTab === "settings" ? "bg-orange-100 text-orange-600" : "hover:bg-gray-100"}`}
                onClick={() => setActiveTab("settings")}
              >
                <Settings className="h-5 w-5" />
                <span>{translations.settings}</span>
              </button>
              <button className="flex items-center gap-2 w-full p-2 rounded-md text-red-600 hover:bg-red-50">
                <LogOut className="h-5 w-5" />
                <span>{translations.logout}</span>
              </button>
            </nav>
          </div>
        </div>

        <div className="md:col-span-3">
          {activeTab === "bookings" && (
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>{translations.myBookings}</CardTitle>
                </CardHeader>
                <CardContent>
                  {bookings.length > 0 ? (
                    <div className="space-y-4">
                      {bookings.map((booking) => (
                        <div key={booking.id} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start mb-2">
                            <h3 className="font-bold">{booking.title}</h3>
                            <span
                              className={`px-2 py-1 text-xs rounded-full ${booking.status === "Confirmed" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}
                            >
                              {booking.status}
                            </span>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-sm mb-4">
                            <div className="flex items-center gap-1">
                              <MapPin className="h-4 w-4 text-gray-500" />
                              <span>{booking.temple}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-4 w-4 text-gray-500" />
                              <span>{new Date(booking.date).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4 text-gray-500" />
                              <span>{booking.time}</span>
                            </div>
                            <div>
                              <span className="font-medium">{booking.price}</span>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              View Details
                            </Button>
                            {booking.status === "Confirmed" && (
                              <Button variant="outline" size="sm">
                                Download Receipt
                              </Button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500 mb-4">You have no bookings yet.</p>
                      <Button asChild>
                        <Link href={`/${locale}/pujas`}>Book a Puja</Link>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "profile" && (
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-500">Full Name</label>
                      <p>John Doe</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-500">Email</label>
                      <p>john.doe@example.com</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-500">Phone</label>
                      <p>+91 98765 43210</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-500">Address</label>
                      <p>123 Main Street, New Delhi, India</p>
                    </div>
                  </div>
                  <Button>Edit Profile</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === "settings" && (
            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-2">Notification Preferences</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <input type="checkbox" id="email-notifications" className="mr-2" defaultChecked />
                        <label htmlFor="email-notifications">Email Notifications</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="sms-notifications" className="mr-2" defaultChecked />
                        <label htmlFor="sms-notifications">SMS Notifications</label>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Language Preference</h3>
                    <select className="w-full p-2 border rounded-md">
                      <option value="en">English</option>
                      <option value="hi">Hindi</option>
                      <option value="sa">Sanskrit</option>
                    </select>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Change Password</h3>
                    <div className="space-y-2">
                      <input type="password" placeholder="Current Password" className="w-full p-2 border rounded-md" />
                      <input type="password" placeholder="New Password" className="w-full p-2 border rounded-md" />
                      <input
                        type="password"
                        placeholder="Confirm New Password"
                        className="w-full p-2 border rounded-md"
                      />
                    </div>
                    <Button className="mt-2">Update Password</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

