"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { type Locale, i18n } from "@/lib/i18n-config"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { LanguageSwitcher } from "@/components/language-switcher"
import { SearchBar } from "@/components/search-bar"
import { Menu, X, Search } from "lucide-react"

interface HeaderProps {
  locale: Locale
  translations?: {
    login: string
    search: string
  }
  navItems?: {
    title: string
    url: string
  }[]
}

// Default navigation items to use when API fails
const defaultNavItems = [
  { title: "Home", url: "" },
  { title: "Pujas", url: "/pujas" },
  { title: "Aartis", url: "/aartis" },
  { title: "Mantras", url: "/mantras" },
  { title: "Temples", url: "/temples" },
  { title: "Blog", url: "/blog" },
  { title: "About", url: "/about" },
  { title: "Contact", url: "/contact" },
]

export function Header({
  locale = i18n.defaultLocale as Locale,
  translations = {
    login: "Login",
    search: "Search",
  },
  navItems: initialNavItems,
}: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false)
  const [navItems, setNavItems] = useState<any[]>(initialNavItems || defaultNavItems)
  const [showSearch, setShowSearch] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Get the path without the locale
  const getPathWithoutLocale = () => {
    const segments = pathname.split("/")
    segments.splice(1, 1)
    return segments.join("/") || "/"
  }

  const pathWithoutLocale = getPathWithoutLocale()

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-200 ${isScrolled ? "bg-white shadow-md" : "bg-white/80 backdrop-blur-sm"}`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <Link href={`/${locale}`} className="mr-6">
              <Image src="/logo.svg" alt="Baglamukhi Pujan" width={180} height={40} className="h-10 w-auto" />
            </Link>

            <nav className="hidden md:flex items-center space-x-6">
              {navItems.map((item, i) => (
                <Link
                  key={i}
                  href={`/${locale}${item.url}`}
                  className={`text-sm font-medium transition-colors hover:text-orange-600 ${
                    item.url === pathWithoutLocale ? "text-orange-600" : "text-gray-700"
                  }`}
                >
                  {item.title}
                </Link>
              ))}
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowSearch(!showSearch)}
              aria-label={translations.search}
            >
              <Search className="h-5 w-5" />
            </Button>

            <LanguageSwitcher locale={locale} />

            <Button variant="outline" className="hidden md:flex">
              {translations.login}
            </Button>

            <Button className="hidden md:flex bg-orange-600 hover:bg-orange-700">Book Puja</Button>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between border-b pb-4">
                    <Link href={`/${locale}`} className="flex items-center">
                      <Image src="/logo.svg" alt="Baglamukhi Pujan" width={180} height={40} className="h-8 w-auto" />
                    </Link>
                    <SheetTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <X className="h-5 w-5" />
                        <span className="sr-only">Close menu</span>
                      </Button>
                    </SheetTrigger>
                  </div>

                  <nav className="flex flex-col space-y-4 py-6">
                    {navItems.map((item, i) => (
                      <Link
                        key={i}
                        href={`/${locale}${item.url}`}
                        className={`text-base font-medium transition-colors hover:text-orange-600 ${
                          item.url === pathWithoutLocale ? "text-orange-600" : "text-gray-700"
                        }`}
                      >
                        {item.title}
                      </Link>
                    ))}
                  </nav>

                  <div className="mt-auto border-t pt-4">
                    <Button className="w-full bg-orange-600 hover:bg-orange-700 mb-3">Book Puja</Button>
                    <Button variant="outline" className="w-full">
                      {translations.login}
                    </Button>
                    <div className="mt-4">
                      <p className="text-sm font-medium mb-2">Language</p>
                      <div className="flex flex-wrap gap-2">
                        {i18n.locales.map((l) => (
                          <Link
                            key={l}
                            href={`/${l}${pathWithoutLocale}`}
                            className={`px-3 py-1 text-sm rounded-md ${
                              l === locale
                                ? "bg-orange-100 text-orange-700"
                                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                            }`}
                          >
                            {l.toUpperCase()}
                          </Link>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>

      {showSearch && (
        <div className="container mx-auto px-4 py-3 border-t">
          <SearchBar locale={locale} />
        </div>
      )}
    </header>
  )
}

