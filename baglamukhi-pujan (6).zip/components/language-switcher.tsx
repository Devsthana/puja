"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { type Locale, i18n } from "@/lib/i18n-config"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Globe } from "lucide-react"

interface LanguageSwitcherProps {
  locale: Locale
}

export function LanguageSwitcher({ locale }: LanguageSwitcherProps) {
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)

  // Get the path without the locale
  const getPathWithoutLocale = () => {
    const segments = pathname.split("/")
    segments.splice(1, 1)
    return segments.join("/") || "/"
  }

  const pathWithoutLocale = getPathWithoutLocale()

  const getLanguageName = (locale: Locale) => {
    switch (locale) {
      case "en":
        return "English"
      case "hi":
        return "हिन्दी"
      case "sa":
        return "संस्कृत"
      default:
        return locale.toUpperCase()
    }
  }

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon">
          <Globe className="h-5 w-5" />
          <span className="sr-only">Switch language</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {i18n.locales.map((l) => (
          <DropdownMenuItem key={l} asChild>
            <Link
              href={`/${l}${pathWithoutLocale}`}
              className={l === locale ? "font-medium text-orange-600" : ""}
              onClick={() => setIsOpen(false)}
            >
              {getLanguageName(l)}
            </Link>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

